# 💊 pharmQ

**Medicine distribution network & inventory planner for the entire United States, in Python and R.**

pharmQ models how medicines move **manufacturing plants → distribution centers (DCs) → pharmacies** across all 50 states, Washington DC and Puerto Rico. It decides where to put DCs, which DC serves which region, how much stock to hold, and where shortages are most likely. It also lets you stress-test the network with plant outages, DC closures and demand surges.

![pharmQ network map](docs/img/network_map.png)

| | Python | R |
|---|---|---|
| Model library | `pharmq/` (pip package + `pharmq` CLI) | `r/pharmqR/` (R package) |
| Web app | Streamlit: `app/streamlit_app.py` | Shiny: `r/shiny/app.R` |
| Network solver | Exact MILP (SciPy HiGHS) + fast heuristic | Heuristic + lpSolve MILP |
| Forecasting | Holt-Winters (additive / multiplicative, auto) | `stats::HoltWinters` (auto) |
| Tests | `pytest` (13 tests) | `testthat` (14 expectations) |

Both implementations read the same reference data and use the same formulas, so you can work in whichever language your team prefers.

---

## What the model does

1. **Demand.** Each state is split into demand zones. Annual demand per SKU = population × per-capita prescribing rate × local variation. Pharmacies are estimated at about 19 per 100k residents.
2. **Forecast.** Builds 3 years of weekly history per SKU and fits Holt-Winters, choosing additive or multiplicative seasonality by 13-week back-test (WAPE, MAPE, bias). It reports 26-week forecasts with 95% intervals.
3. **Network design** (capacitated facility location):
   - chooses which candidate DCs to open, trading DC fixed cost against inbound (plant → DC) and outbound (DC → zone) freight
   - each zone × handling class (**ambient / cold chain 2–8 °C / DEA Schedule II**) is single-sourced
   - cold freight only goes to refrigerated DCs and Schedule II only to DEA-vault DCs
   - air freight is used for Alaska, Hawaii, Puerto Rico and lanes that are too long for ground or cold-chain
   - DCs can be forced open or closed, and the DC count can be bounded
4. **Inventory policy** per DC × SKU: safety stock with demand and lead-time uncertainty, reorder point, EOQ capped by shelf life, plus peak-season values.
5. **Simulation.** A 365-day stochastic run with seasonal demand, random lead times, FEFO lot picking with expiry write-offs, and optional plant outages that fail over to backup plants.
6. **Shortage risk.** A 0–100 score per SKU built from single sourcing, service gap, volatility, lead-time variability, handling complexity and shelf-life pressure.

Baseline result (bundled data): 11 DCs, about **$184M/yr** network cost (**$0.10 per pack**), **94%** of the population reachable next day, **98.4%** simulated fill rate.

> ⚠️ The bundled population figures come from the 2020 Census. Costs, capacities, prescribing rates and lead times are **illustrative**. Replace them with your own data before using results for real decisions.

---

## Quick start

### Python
```bash
git clone https://github.com/<you>/pharmQ.git && cd pharmQ
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt && pip install -e ".[dev]"

streamlit run app/streamlit_app.py                     # web app → http://localhost:8501
pharmq run --config config/default.toml --out results  # CLI: writes CSVs + summary.json
pytest -q                                              # tests
```

```python
from pharmq import Config, Outage, run

res = run(Config(service_level=0.99, force_closed=["DC-MEM"]),
          outage=Outage("PL-NJ", start_day=30, duration_days=90))
print(res.summary())
res.solution.open_sites      # which DCs, utilization
res.solution.lanes           # DC → zone assignments, miles, mode, cost
res.policy                   # safety stock / reorder point / order qty
res.risk                     # shortage risk ranking
res.export("results/")
```

### R
```r
# from the repo root
install.packages(c("shiny", "lpSolve", "maps", "jsonlite", "testthat"))
install.packages("r/pharmqR", repos = NULL, type = "source")

library(pharmqR)
res <- pq_run(pq_config(service_level = 0.99), outage = pq_outage("PL-NJ", 30, 90))
res                      # prints KPIs
res$solution$open_sites
pq_export(res, "results_r")

shiny::runApp("r/shiny")    # web app
```

### Docker (both apps at once)
```bash
docker compose up --build
# Python/Streamlit → http://localhost:8501
# R/Shiny          → http://localhost:3838/pharmq/
```

---

## Deploy

| Where | How |
|---|---|
| **Streamlit Community Cloud** (free) | Push to GitHub → share.streamlit.io → *New app* → repo `pharmQ`, main file `app/streamlit_app.py`. |
| **shinyapps.io** (free tier) | `rsconnect::deployApp("r/shiny")`. Install `pharmqR` first, or remove the package check so the app sources `../pharmqR/R`. |
| **Render / Railway / Fly.io / Cloud Run** | Point them at the `Dockerfile` (port 8501) or `Dockerfile.shiny` (port 3838). |
| **Posit Connect** | Publish `r/shiny` or `app/streamlit_app.py` directly. |

CI (`.github/workflows/ci.yml`) runs on every push. It lints and tests Python on 3.11–3.13, smoke-tests the Streamlit app, tests the R package, checks that the Python and R data copies match, and builds the Docker image.

---

## Use your own data

Every table can be swapped out: upload it in either app's sidebar, pass it to the CLI (`--sites`, `--products`, `--plants`, `--zones`), or pass a DataFrame in code. Column definitions are in **[docs/DATA_SCHEMA.md](docs/DATA_SCHEMA.md)**, and you can download templates from the app's *Data & export* tab.

Ideas for real-world inputs: Census ACS (population by county), CMS Part D prescriber data (prescribing rates), FDA NDC directory (products), FDA drug shortage list (risk validation), DEA ARCOS (controlled-substance flows), and your own DC and freight contracts.

## Configuration

All knobs are in `config/default.toml`: zones per state, state subset, demand surges, solver, DC limits, forced sites, freight rates, air rules, service level, holding and ordering cost, shelf-life cap, and simulation length. The apps expose the same settings as sliders, plus one-click **scenario presets**: severe flu season, New Jersey plant outage, closing two major hubs, and GLP-1 demand doubling.

## Project layout
```
pharmQ/
├── pharmq/                 Python package
│   ├── data/               reference CSVs (states, DC sites, plants, products)
│   ├── data.py  geo.py  config.py
│   ├── network.py          facility location (MILP + heuristic)
│   ├── forecast.py         Holt-Winters
│   ├── inventory.py        safety stock / ROP / EOQ
│   ├── simulation.py       stochastic daily simulation with expiry & outages
│   ├── risk.py             shortage-risk scoring
│   ├── pipeline.py         end-to-end run + export
│   └── cli.py
├── app/streamlit_app.py    Python web app
├── r/pharmqR/              R package (same model)
├── r/shiny/app.R           R web app
├── tests/                  pytest suite
├── config/default.toml
├── Dockerfile  Dockerfile.shiny  docker-compose.yml
└── .github/workflows/ci.yml
```

## License
MIT. See [LICENSE](LICENSE).
