"""pharmQ - interactive web app.   Run:  streamlit run app/streamlit_app.py"""
from __future__ import annotations

import io
import json
import sys
import zipfile
from pathlib import Path

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from pharmq import Config, Outage, build_network, load_table, run

st.set_page_config(page_title="pharmQ - US Medicine Distribution", page_icon="💊", layout="wide")

HANDLING_COLORS = {"ambient": "#2E86AB", "cold": "#00A6A6", "controlled": "#C73E1D"}
TIER_COLORS = {"Low": "#3BB273", "Medium": "#F4A259", "High": "#D7263D"}

SCENARIOS = {
    "Baseline": {},
    "Severe flu season (+150% antivirals & vaccine)": {"sku_multipliers": {"OSEL75": 2.5, "FLUV": 2.5, "AMOX500": 1.4}},
    "New Jersey plant outage (90 days)": {"outage": ("PL-NJ", 90)},
    "Columbus + Allentown hubs closed": {"force_closed": ["DC-CMH", "DC-ABE"]},
    "GLP-1 demand doubles": {"sku_multipliers": {"SEMA": 2.0}},
}


def money(x: float) -> str:
    for unit, div in (("B", 1e9), ("M", 1e6), ("K", 1e3)):
        if abs(x) >= div:
            return f"${x / div:,.1f}{unit}"
    return f"${x:,.0f}"


@st.cache_data(show_spinner=False)
def reference(name: str) -> pd.DataFrame:
    return load_table(name)


@st.cache_data(show_spinner="Optimizing the national network...")
def compute(cfg_json: str, outage_json: str, uploads: dict[str, str]):
    cfg = Config(**json.loads(cfg_json))
    custom = {k: pd.read_csv(io.StringIO(v)) for k, v in uploads.items() if k != "zones"}
    zones = pd.read_csv(io.StringIO(uploads["zones"])) if "zones" in uploads else None
    net = build_network(cfg.zones_per_state, cfg.seed, cfg.demand_multiplier, cfg.sku_multipliers,
                        include_states=cfg.include_states, zones=zones,
                        local_variation=cfg.local_variation, **custom)
    o = json.loads(outage_json)
    outage = Outage(o["plant"], o["start"], o["days"]) if o else None
    return run(cfg, net, outage)


# ============================================================================ sidebar
st.sidebar.title("💊 pharmQ")
st.sidebar.caption("Medicine distribution planner for the United States")

scenario = st.sidebar.selectbox("Scenario preset", list(SCENARIOS), help="Pick a ready-made what-if, then fine-tune below.")
preset = SCENARIOS[scenario]
states_df = reference("states")
sites_df = reference("dc_sites")
plants_df = reference("plants")
products_df = reference("products")

with st.sidebar.expander("🗺️ Coverage", expanded=False):
    regions = st.multiselect("Regions", sorted(states_df["region"].unique()), default=sorted(states_df["region"].unique()))
    zones_per_state = st.slider("Demand zones per large state", 1, 4, 1,
                                help="Split big states into sub-regions for a finer network (slower).")
    demand_mult = st.slider("Overall demand level", 0.5, 2.0, 1.0, 0.05)

with st.sidebar.expander("🏭 Network design", expanded=True):
    solver = st.radio("Optimizer", ["auto", "milp", "heuristic"], horizontal=True,
                      help="MILP = exact (HiGHS). Heuristic = fast greedy + swap.")
    min_dcs, max_dcs = st.slider("Number of DCs allowed", 1, len(sites_df), (1, 20))
    closed = st.multiselect("Force closed", sites_df["site_id"], default=preset.get("force_closed", []), key=f"closed-{scenario}")
    forced = st.multiselect("Force open", [s for s in sites_df["site_id"] if s not in closed])

with st.sidebar.expander("🚚 Transport rates ($/pack-mile)"):
    r_amb = st.number_input("Ambient", value=0.00010, format="%.5f", step=0.00001)
    r_cold = st.number_input("Cold chain (2-8°C)", value=0.00035, format="%.5f", step=0.00001)
    r_ctrl = st.number_input("Controlled (DEA CII)", value=0.00018, format="%.5f", step=0.00001)
    air_mult = st.slider("Air freight multiplier", 2.0, 12.0, 6.0, 0.5)
    cold_ground = st.slider("Max cold-chain ground miles", 300, 2500, 1200, 50)

with st.sidebar.expander("📦 Inventory policy", expanded=True):
    service = st.slider("Target service level", 0.90, 0.995, 0.98, 0.005, format="%.3f")
    holding = st.slider("Holding cost (% of value / yr)", 0.05, 0.40, 0.22, 0.01)
    order_cost = st.number_input("Cost per order ($)", value=450, step=50)

with st.sidebar.expander("⚠️ Disruption & demand surge", expanded=bool(preset.get("outage") or preset.get("sku_multipliers"))):
    def_out = preset.get("outage")
    outage_on = st.checkbox("Simulate plant outage", value=bool(def_out), key=f"oon-{scenario}")
    outage_plant = st.selectbox("Plant", plants_df["plant_id"],
                                index=list(plants_df["plant_id"]).index(def_out[0]) if def_out else 0,
                                disabled=not outage_on, key=f"op-{scenario}")
    outage_days = st.slider("Outage length (days)", 7, 180, def_out[1] if def_out else 60, disabled=not outage_on, key=f"od-{scenario}")
    surge_default = preset.get("sku_multipliers", {})
    surge_skus = st.multiselect("Demand surge on SKUs", products_df["sku"], default=list(surge_default), key=f"ss-{scenario}")
    surge = st.slider("Surge multiplier", 1.0, 4.0, float(max(surge_default.values(), default=1.5)), 0.1,
                      key=f"sm-{scenario}") if surge_skus else 1.0

with st.sidebar.expander("📁 Bring your own data"):
    st.caption("Upload CSVs with the same columns as the downloadable templates (Data tab).")
    uploads = {}
    for key, label in (("zones", "Demand zones"), ("sites", "DC sites"), ("plants", "Plants"), ("products", "Products")):
        f = st.file_uploader(label, type="csv", key=f"up_{key}")
        if f is not None:
            uploads[key] = f.getvalue().decode("utf-8")

include = states_df.loc[states_df["region"].isin(regions), "state"].tolist()
cfg = Config(zones_per_state=zones_per_state, demand_multiplier=demand_mult,
             include_states=None if len(include) == len(states_df) else include,
             sku_multipliers={s: surge for s in surge_skus}, solver=solver, min_dcs=min_dcs, max_dcs=max_dcs,
             force_open=forced, force_closed=closed, rate_ambient=r_amb, rate_cold=r_cold,
             rate_controlled=r_ctrl, air_multiplier=air_mult, max_cold_ground_miles=float(cold_ground),
             service_level=service, holding_rate=holding, order_cost_usd=float(order_cost))
outage_json = json.dumps({"plant": outage_plant, "start": 30, "days": outage_days} if outage_on else {})

if not include:
    st.warning("Select at least one region.")
    st.stop()

try:
    res = compute(json.dumps(cfg.to_dict()), outage_json, uploads)
except Exception as e:  # show friendly error instead of a stack trace
    st.error(f"Could not build a network with these settings: {e}")
    st.stop()

S = res.summary()
sol = res.solution

# ============================================================================ header & KPIs
st.title("pharmQ · US Medicine Distribution Planner")
st.caption(f"Scenario: **{scenario}** · {S['zones']} demand zones · {S['population'] / 1e6:,.0f}M people · "
           f"{S['skus']} SKUs · solver: {S['solver']} · computed in {sum(S['timings_s'].values()):.1f}s")
k = st.columns(6)
k[0].metric("DCs open", S["dcs_open"])
k[1].metric("Network cost / yr", money(S["total_cost_usd"]), help="DC fixed cost + inbound + outbound transport")
k[2].metric("Cost per pack", f"${S['cost_per_pack_usd']:.3f}")
k[3].metric("Next-day reach", f"{S['pct_pop_next_day']:.0%}", help="Share of population reachable within 2 days incl. handling (ambient)")
k[4].metric("Simulated fill rate", f"{S['fill_rate']:.1%}", delta=f"{S['fill_rate'] - service:+.1%} vs target")
k[5].metric("Inventory value", money(S["inventory_value_usd"]))

tabs = st.tabs(["🗺️ Network map", "🏭 Distribution centers", "📈 Demand forecast",
                "📦 Inventory policy", "🎲 Simulation", "⚠️ Shortage risk", "📤 Data & export", "ℹ️ How it works"])

# ---------------------------------------------------------------------------- map
with tabs[0]:
    c1, c2 = st.columns([3, 1])
    with c2:
        show_h = st.multiselect("Lanes to show", ["ambient", "cold", "controlled"], default=["ambient"])
        show_cand = st.checkbox("Show closed candidate sites", True)
        show_plants = st.checkbox("Show manufacturing plants", True)
    lanes = sol.lanes[sol.lanes["handling"].isin(show_h)]
    fig = go.Figure()
    for h in show_h:
        L = lanes[lanes["handling"] == h]
        lat, lon = [], []
        for _, r in L.iterrows():
            lat += [r["dc_lat"], r["zone_lat"], None]
            lon += [r["dc_lon"], r["zone_lon"], None]
        fig.add_trace(go.Scattergeo(lat=lat, lon=lon, mode="lines", name=f"{h} lanes",
                                    line=dict(width=1, color=HANDLING_COLORS[h]), opacity=0.55, hoverinfo="skip"))
    z = res.network.zones.merge(sol.lanes[sol.lanes["handling"] == "ambient"][["zone_id", "site_id", "miles"]], on="zone_id", how="left")
    fig.add_trace(go.Scattergeo(lat=z["lat"], lon=z["lon"], mode="markers", name="Demand zones",
                                marker=dict(size=np.clip(np.sqrt(z["population"]) / 220, 4, 22), color="#888", opacity=0.6),
                                text=z.apply(lambda r: f"{r.zone_id}<br>{r.population:,} people<br>{r.pharmacies:,} pharmacies<br>"
                                                       f"served by {r.site_id} ({r.miles:,.0f} mi)", axis=1), hoverinfo="text"))
    if show_cand:
        cl = res.network.sites[~res.network.sites["site_id"].isin(sol.open_sites["site_id"])]
        fig.add_trace(go.Scattergeo(lat=cl["lat"], lon=cl["lon"], mode="markers", name="Candidate (closed)",
                                    marker=dict(size=7, symbol="square-open", color="#999"),
                                    text=cl["site_id"] + " · " + cl["city"], hoverinfo="text"))
    o = sol.open_sites
    fig.add_trace(go.Scattergeo(lat=o["lat"], lon=o["lon"], mode="markers+text", name="Open DC",
                                marker=dict(size=14 + 10 * o["utilization"], symbol="star", color="#F18F01", line=dict(width=1, color="#333")),
                                text=o["site_id"].str.replace("DC-", ""), textposition="top center",
                                hovertext=o.apply(lambda r: f"{r.site_id} {r.city}, {r.state}<br>{r.throughput_mpacks:,.0f}M packs/yr"
                                                            f"<br>utilization {r.utilization:.0%}", axis=1), hoverinfo="text"))
    if show_plants:
        p = res.network.plants
        fig.add_trace(go.Scattergeo(lat=p["lat"], lon=p["lon"], mode="markers", name="Plant",
                                    marker=dict(size=10, symbol="diamond", color="#6A4C93"),
                                    text=p["plant_id"] + " · " + p["name"], hoverinfo="text"))
    fig.update_geos(scope="usa", showland=True, landcolor="#f5f5f2", showlakes=False)
    fig.update_layout(height=620, margin=dict(l=0, r=0, t=10, b=0), legend=dict(orientation="h", y=-0.02))
    with c1:
        st.plotly_chart(fig, width="stretch")
    with c2:
        st.markdown("**Cost breakdown**")
        st.plotly_chart(px.pie(values=[S["fixed_cost_usd"], S["transport_cost_usd"]], names=["DC fixed", "Transport"],
                               hole=0.55, color_discrete_sequence=["#F18F01", "#2E86AB"]).update_layout(
            height=230, margin=dict(l=0, r=0, t=0, b=0), showlegend=True), width="stretch")
        st.metric("Avg distance to pharmacy zone", f"{S['avg_miles']:,.0f} mi")
        st.metric("Volume shipped by air", f"{S['pct_volume_air']:.1%}")

# ---------------------------------------------------------------------------- DCs
with tabs[1]:
    o = sol.open_sites.copy()
    st.subheader(f"{len(o)} distribution centers selected")
    st.dataframe(o[["site_id", "city", "state", "throughput_mpacks", "capacity_mpacks", "utilization", "zones_served",
                    "fixed_cost_musd", "cold_chain", "dea_vault"]],
                 column_config={"utilization": st.column_config.ProgressColumn("Utilization", min_value=0, max_value=1, format="%.0f%%"),
                                "throughput_mpacks": st.column_config.NumberColumn("Throughput (M packs)", format="%.1f"),
                                "capacity_mpacks": st.column_config.NumberColumn("Capacity (M packs)"),
                                "fixed_cost_musd": st.column_config.NumberColumn("Fixed $M/yr", format="%.1f"),
                                "cold_chain": st.column_config.CheckboxColumn("Cold chain"),
                                "dea_vault": st.column_config.CheckboxColumn("DEA vault")},
                 hide_index=True, width="stretch")
    a, b = st.columns(2)
    by = sol.lanes.groupby(["site_id", "handling"], as_index=False)["annual_packs"].sum()
    a.plotly_chart(px.bar(by, x="site_id", y="annual_packs", color="handling", color_discrete_map=HANDLING_COLORS,
                          title="Volume by DC and handling class", labels={"annual_packs": "packs / yr", "site_id": ""}),
                   width="stretch")
    st_sel = b.selectbox("Zones served by", o["site_id"])
    b.dataframe(sol.lanes[sol.lanes["site_id"] == st_sel][["zone_id", "handling", "annual_packs", "miles", "mode", "transit_days", "annual_cost_usd"]]
                .sort_values("annual_packs", ascending=False).round(0), hide_index=True, width="stretch", height=380)

# ---------------------------------------------------------------------------- forecast
with tabs[2]:
    c1, c2 = st.columns([1, 3])
    sku = c1.selectbox("SKU", products_df["sku"], format_func=lambda s: f"{s} · {products_df.set_index('sku').loc[s, 'name']}")
    acc = res.accuracy.set_index("sku").loc[sku]
    c1.metric("Back-test error (WAPE)", f"{acc['wape']:.1%}")
    c1.metric("Bias", f"{acc['bias']:+.1%}")
    c1.caption(f"Holt-Winters ({acc['model']}) · α={acc['alpha']} β={acc['beta']} γ={acc['gamma']}")
    hist = res.history[res.history["sku"] == sku]
    fc = res.forecast[res.forecast["sku"] == sku]
    f = go.Figure()
    f.add_trace(go.Scatter(x=hist["week"], y=hist["packs"], name="History", line=dict(color="#555")))
    f.add_trace(go.Scatter(x=pd.concat([fc["week"], fc["week"][::-1]]), y=pd.concat([fc["hi95"], fc["lo95"][::-1]]),
                           fill="toself", fillcolor="rgba(241,143,1,0.2)", line=dict(width=0), name="95% interval"))
    f.add_trace(go.Scatter(x=fc["week"], y=fc["forecast"], name="Forecast", line=dict(color="#F18F01", width=3)))
    f.update_layout(height=430, xaxis_title="week", yaxis_title="national packs / week", margin=dict(t=20))
    c2.plotly_chart(f, width="stretch")
    st.dataframe(res.accuracy.round(3), hide_index=True, width="stretch")

# ---------------------------------------------------------------------------- inventory
with tabs[3]:
    pol = res.policy
    c1, c2, c3 = st.columns(3)
    c1.metric("Safety stock value", money(float((pol["safety_stock"] * pol["unit_cost"]).sum())))
    c2.metric("Annual holding cost", money(float(pol["holding_cost_usd"].sum())))
    c3.metric("SKU-DCs capped by shelf life", int(pol["shelf_life_capped"].sum()))
    dc = st.selectbox("Distribution center", ["All"] + sorted(pol["site_id"].unique()))
    view = pol if dc == "All" else pol[pol["site_id"] == dc]
    st.dataframe(view[["site_id", "sku", "name", "handling", "daily_demand", "lead_time", "safety_stock", "reorder_point",
                       "reorder_point_peak", "order_qty", "days_of_supply", "inventory_value_usd"]].round(1),
                 hide_index=True, width="stretch")
    st.plotly_chart(px.treemap(pol, path=["handling", "sku", "site_id"], values="inventory_value_usd",
                               color="handling", color_discrete_map=HANDLING_COLORS,
                               title="Where the inventory money sits"), width="stretch")

# ---------------------------------------------------------------------------- simulation
with tabs[4]:
    sim = res.sim.merge(products_df[["sku", "handling"]], on="sku")
    if outage_on:
        st.info(f"Includes a {outage_days}-day outage at **{outage_plant}** starting on day 30.")
    c1, c2, c3 = st.columns(3)
    c1.metric("Network fill rate", f"{S['fill_rate']:.2%}")
    c2.metric("Worst SKU-DC fill rate", f"{sim['fill_rate'].min():.1%}")
    c3.metric("Expired stock", money(S["expired_value_usd"]))
    heat = sim.pivot_table(index="sku", columns="site_id", values="fill_rate")
    st.plotly_chart(px.imshow(heat, color_continuous_scale="RdYlGn", zmin=0.85, zmax=1, aspect="auto",
                              title="Fill rate by SKU and DC (365-day simulation)", text_auto=".2f"),
                    width="stretch")
    st.dataframe(sim.round(3), hide_index=True, width="stretch")

# ---------------------------------------------------------------------------- risk
with tabs[5]:
    rk = res.risk
    st.plotly_chart(px.bar(rk, x="risk_score", y="sku", color="risk_tier", orientation="h",
                           color_discrete_map=TIER_COLORS, hover_data=["name", "main_driver", "fill_rate"],
                           title="Shortage risk score (0-100)").update_yaxes(categoryorder="total ascending"),
                    width="stretch")
    comp = rk.set_index("sku")[[c for c in rk.columns if c.startswith("c_")]]
    comp.columns = [c[2:].replace("_", " ") for c in comp.columns]
    st.plotly_chart(px.imshow(comp, color_continuous_scale="Reds", zmin=0, zmax=1, aspect="auto",
                              title="Risk drivers (0 = none, 1 = maximum)"), width="stretch")
    st.caption("Mitigations: qualify a backup plant for single-source SKUs, raise service level or pre-build "
               "ahead of season for volatile SKUs, add cold-chain capacity closer to demand.")

# ---------------------------------------------------------------------------- export
with tabs[6]:
    st.subheader("Download results")
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for name, df in {"open_dcs": sol.open_sites, "lanes": sol.lanes, "inventory_policy": res.policy,
                         "simulation": res.sim, "shortage_risk": res.risk, "forecast": res.forecast,
                         "forecast_accuracy": res.accuracy, "zones": res.network.zones, "demand": res.network.demand}.items():
            zf.writestr(f"{name}.csv", df.to_csv(index=False))
        zf.writestr("summary.json", json.dumps(S, indent=2, default=float))
        zf.writestr("config.json", json.dumps(cfg.to_dict(), indent=2))
    st.download_button("⬇️ Download everything (.zip)", buf.getvalue(), "pharmq_results.zip", "application/zip", type="primary")
    a, b = st.columns(2)
    a.download_button("Lanes (CSV)", sol.lanes.to_csv(index=False), "lanes.csv")
    b.download_button("Inventory policy (CSV)", res.policy.to_csv(index=False), "inventory_policy.csv")
    st.subheader("Data templates")
    st.caption("Edit these and upload them in the sidebar to model your own network.")
    t = st.columns(4)
    for col, (nm, df) in zip(t, {"zones": res.network.zones, "dc_sites": sites_df, "plants": plants_df, "products": products_df}.items(), strict=False):
        col.download_button(f"{nm}.csv", df.to_csv(index=False), f"{nm}.csv")
    with st.expander("Preview product catalog"):
        st.dataframe(products_df, hide_index=True, width="stretch")

# ---------------------------------------------------------------------------- about
with tabs[7]:
    st.markdown("""
**pharmQ** plans how medicines move from manufacturing plants → distribution centers (DCs) → pharmacies across the US.

1. **Demand**: every state (plus DC and Puerto Rico) is split into demand zones; demand per SKU = population × per-capita
   prescribing rate × local variation. Pharmacies ≈ 19 per 100k residents.
2. **Forecast**: 3 years of weekly history per SKU, Holt-Winters (additive or multiplicative, chosen by back-test).
3. **Network design**: a mixed-integer program picks which DCs to open and assigns every zone × handling class
   (ambient / cold chain / DEA-controlled) to one DC, trading off fixed DC cost against inbound and outbound freight.
   Cold-chain freight only goes to refrigerated DCs, Schedule II only to DEA-vault DCs, and long or overseas lanes go by air.
4. **Inventory**: safety stock, reorder point and order quantity per DC × SKU (EOQ capped by shelf life), with peak-season values.
5. **Simulation**: 365-day stochastic run with random demand and lead times, FEFO lot expiry and optional plant outages.
6. **Risk**: shortage-risk score per SKU from sourcing, service, volatility, lead-time, handling and shelf-life factors.

*Bundled numbers are illustrative (2020 Census populations; synthetic costs and demand rates). Replace them with your own data.*
""")
