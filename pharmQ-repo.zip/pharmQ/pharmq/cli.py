"""Command line interface:  pharmq run --config config/default.toml --out results/"""
from __future__ import annotations

import argparse
import json
import sys

from . import __version__
from .config import Config
from .data import build_network, load_table
from .pipeline import run
from .simulation import Outage


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="pharmq", description="pharmQ - US medicine distribution model")
    ap.add_argument("--version", action="version", version=f"pharmq {__version__}")
    sub = ap.add_subparsers(dest="cmd", required=True)

    r = sub.add_parser("run", help="run the full pipeline and export CSV/JSON results")
    r.add_argument("--config", help="TOML config file")
    r.add_argument("--out", default="results", help="output folder")
    r.add_argument("--zones", type=str, help="custom zones CSV (zone_id,state,region,population,lat,lon,island,pharmacies)")
    r.add_argument("--sites", help="custom DC candidate sites CSV")
    r.add_argument("--plants", help="custom plants CSV")
    r.add_argument("--products", help="custom products CSV")
    r.add_argument("--solver", choices=["auto", "milp", "heuristic"])
    r.add_argument("--close", nargs="*", default=[], help="DC site_ids to force closed")
    r.add_argument("--outage-plant", help="simulate an outage at this plant_id")
    r.add_argument("--outage-days", type=int, default=60)

    sub.add_parser("sites", help="list candidate distribution centers")
    sub.add_parser("products", help="list the SKU catalog")
    a = ap.parse_args(argv)

    if a.cmd == "sites":
        print(load_table("dc_sites").to_string(index=False)); return 0
    if a.cmd == "products":
        print(load_table("products").to_string(index=False)); return 0

    import pandas as pd
    cfg = Config.from_toml(a.config) if a.config else Config()
    if a.solver:
        cfg.solver = a.solver
    cfg.force_closed = list(set(cfg.force_closed) | set(a.close))
    custom = {k: pd.read_csv(getattr(a, k)) for k in ("sites", "plants", "products") if getattr(a, k)}
    zones = pd.read_csv(a.zones) if a.zones else None
    net = build_network(cfg.zones_per_state, cfg.seed, cfg.demand_multiplier, cfg.sku_multipliers,
                        include_states=cfg.include_states, zones=zones,
                        local_variation=cfg.local_variation, **custom)
    outage = Outage(a.outage_plant, duration_days=a.outage_days) if a.outage_plant else None
    res = run(cfg, net, outage)
    out = res.export(a.out)
    print(json.dumps(res.summary(), indent=2, default=float))
    print(f"\nResults written to {out.resolve()}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
