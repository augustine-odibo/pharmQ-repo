"""Model configuration. Load from TOML or build in code; every field has a sensible default."""
from __future__ import annotations

import tomllib
from dataclasses import asdict, dataclass, field, fields
from pathlib import Path


@dataclass
class Config:
    # --- network generation ---
    zones_per_state: int = 1
    seed: int = 7
    demand_multiplier: float = 1.0
    include_states: list[str] | None = None          # None = all 50 states + DC + PR
    sku_multipliers: dict[str, float] = field(default_factory=dict)  # demand surge per SKU
    local_variation: float = 0.08     # lognormal sigma of local prescribing variation (0 = none)

    # --- network design ---
    solver: str = "auto"              # "auto" | "milp" | "heuristic"
    min_dcs: int = 1
    max_dcs: int = 30
    force_open: list[str] = field(default_factory=list)
    force_closed: list[str] = field(default_factory=list)
    time_limit_s: int = 60

    # --- transport ($ per pack-mile, outbound DC -> pharmacy zone) ---
    rate_ambient: float = 0.00010
    rate_controlled: float = 0.00018
    rate_cold: float = 0.00035
    rate_inbound: float = 0.00002     # full-truckload plant -> DC
    air_multiplier: float = 6.0       # air freight cost multiplier
    max_ground_miles: float = 2500.0  # beyond this, use air
    max_cold_ground_miles: float = 1200.0  # cold chain switches to air sooner

    # --- inventory policy ---
    service_level: float = 0.98
    order_cost_usd: float = 450.0
    holding_rate: float = 0.22        # annual holding cost as share of unit cost
    review_period_days: int = 7
    max_shelf_life_share: float = 0.35  # never order more than this share of shelf life

    # --- simulation ---
    sim_days: int = 365
    sim_seed: int = 42

    @classmethod
    def from_toml(cls, path: str | Path) -> Config:
        with open(path, "rb") as fh:
            raw = tomllib.load(fh)
        flat: dict = {}
        for k, v in raw.items():  # allow [sections] or flat keys
            if isinstance(v, dict) and k != "sku_multipliers":
                flat.update(v)
            else:
                flat[k] = v
        known = {f.name for f in fields(cls)}
        unknown = set(flat) - known
        if unknown:
            raise ValueError(f"Unknown config keys: {sorted(unknown)}")
        return cls(**flat)

    def to_dict(self) -> dict:
        return asdict(self)

    def rate_for(self, handling: str) -> float:
        return {"ambient": self.rate_ambient, "cold": self.rate_cold,
                "controlled": self.rate_controlled}[handling]
