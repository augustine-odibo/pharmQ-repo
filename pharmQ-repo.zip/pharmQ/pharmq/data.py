"""Reference data loading and synthetic US pharmaceutical network generation.

Every table can be replaced with your own CSV that has the same columns
(see docs/DATA_SCHEMA.md). The bundled reference data covers the 50 states,
Washington DC and Puerto Rico.
"""
from __future__ import annotations

from dataclasses import dataclass
from importlib import resources
from pathlib import Path

import numpy as np
import pandas as pd

HANDLING_CLASSES = ("ambient", "cold", "controlled")

REQUIRED_COLUMNS = {
    "states": ["state", "name", "region", "population", "lat", "lon", "island"],
    "dc_sites": ["site_id", "city", "state", "lat", "lon", "fixed_cost_musd",
                 "capacity_mpacks", "cold_chain", "dea_vault"],
    "plants": ["plant_id", "name", "state", "lat", "lon"],
    "products": ["sku", "name", "therapeutic_class", "handling", "unit_cost",
                 "annual_packs_per_1k", "demand_cv", "season_amp", "season_peak_month",
                 "trend_pct", "shelf_life_days", "lead_time_days", "lead_time_sd",
                 "primary_plant", "backup_plant"],
}


def _data_path(name: str) -> Path:
    return Path(str(resources.files("pharmq") / "data" / f"{name}.csv"))


def validate(df: pd.DataFrame, table: str) -> pd.DataFrame:
    """Check that a user-supplied table has the required columns."""
    missing = [c for c in REQUIRED_COLUMNS[table] if c not in df.columns]
    if missing:
        raise ValueError(f"Table '{table}' is missing columns: {', '.join(missing)}")
    if table == "products":
        bad = set(df["handling"]) - set(HANDLING_CLASSES)
        if bad:
            raise ValueError(f"Unknown handling class(es): {bad}. Use {HANDLING_CLASSES}")
        df = df.copy()
        df["backup_plant"] = df["backup_plant"].fillna("").astype(str)
    return df


def load_table(table: str, path: str | Path | None = None) -> pd.DataFrame:
    df = pd.read_csv(path or _data_path(table), keep_default_na=True)
    return validate(df, table)


@dataclass
class Network:
    """All inputs of the model in one container."""
    zones: pd.DataFrame      # demand zones (one or more per state)
    sites: pd.DataFrame      # candidate distribution centers
    plants: pd.DataFrame     # manufacturing plants
    products: pd.DataFrame   # SKU catalog
    demand: pd.DataFrame     # zone x sku annual demand (packs)

    def summary(self) -> dict:
        return {
            "zones": len(self.zones),
            "population": int(self.zones["population"].sum()),
            "candidate_dcs": len(self.sites),
            "plants": len(self.plants),
            "skus": len(self.products),
            "annual_packs": float(self.demand["annual_packs"].sum()),
            "annual_value_usd": float(self.demand["annual_value_usd"].sum()),
        }


def build_zones(states: pd.DataFrame, zones_per_state: int = 1, seed: int = 7,
                include: list[str] | None = None) -> pd.DataFrame:
    """Split each state into demand zones (sub-regions) around its centroid."""
    rng = np.random.default_rng(seed)
    st = states if include is None else states[states["state"].isin(include)]
    rows = []
    for _, s in st.iterrows():
        n = 1 if s["population"] < 1_000_000 else zones_per_state
        weights = rng.dirichlet(np.full(n, 4.0)) if n > 1 else np.array([1.0])
        spread = 0.0 if n == 1 else min(2.0, 0.4 + s["population"] / 15e6)
        for i, w in enumerate(weights):
            rows.append({
                "zone_id": f"{s['state']}-{i + 1}",
                "state": s["state"],
                "region": s["region"],
                "population": int(round(s["population"] * w)),
                "lat": s["lat"] + (rng.normal(0, spread * 0.5) if n > 1 else 0.0),
                "lon": s["lon"] + (rng.normal(0, spread) if n > 1 else 0.0),
                "island": int(s["island"]),
                # ~ 19 community pharmacies per 100k residents in the US
                "pharmacies": max(1, int(round(s["population"] * w * 19 / 100_000))),
            })
    return pd.DataFrame(rows)


def build_demand(zones: pd.DataFrame, products: pd.DataFrame, seed: int = 11,
                 demand_multiplier: float = 1.0,
                 sku_multipliers: dict[str, float] | None = None,
                 local_variation: float = 0.08) -> pd.DataFrame:
    """Annual demand per zone and SKU = per-capita rate x population x local factor."""
    rng = np.random.default_rng(seed)
    sku_multipliers = sku_multipliers or {}
    z = zones[["zone_id", "state", "population"]].assign(key=1)
    p = products[["sku", "handling", "unit_cost", "annual_packs_per_1k"]].assign(key=1)
    d = z.merge(p, on="key").drop(columns="key")
    # regional prescribing variation
    local = rng.lognormal(0.0, local_variation, size=len(d)) if local_variation > 0 else np.ones(len(d))
    mult = d["sku"].map(sku_multipliers).fillna(1.0).to_numpy()
    d["annual_packs"] = d["population"] / 1000 * d["annual_packs_per_1k"] * local * mult * demand_multiplier
    d["annual_value_usd"] = d["annual_packs"] * d["unit_cost"]
    return d[["zone_id", "state", "sku", "handling", "annual_packs", "annual_value_usd"]]


def build_network(zones_per_state: int = 1, seed: int = 7, demand_multiplier: float = 1.0,
                  sku_multipliers: dict[str, float] | None = None,
                  states: pd.DataFrame | None = None, sites: pd.DataFrame | None = None,
                  plants: pd.DataFrame | None = None, products: pd.DataFrame | None = None,
                  include_states: list[str] | None = None,
                  zones: pd.DataFrame | None = None, local_variation: float = 0.08) -> Network:
    """Assemble a Network from bundled or user-supplied tables."""
    states = validate(states, "states") if states is not None else load_table("states")
    sites = validate(sites, "dc_sites") if sites is not None else load_table("dc_sites")
    plants = validate(plants, "plants") if plants is not None else load_table("plants")
    products = validate(products, "products") if products is not None else load_table("products")
    if zones is None:
        zones = build_zones(states, zones_per_state, seed, include_states)
    demand = build_demand(zones, products, seed + 4, demand_multiplier, sku_multipliers, local_variation)
    return Network(zones=zones, sites=sites, plants=plants, products=products, demand=demand)
