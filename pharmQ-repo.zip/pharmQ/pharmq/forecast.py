"""Demand history synthesis and Holt-Winters forecasting (weekly, 52-week seasonality)."""
from __future__ import annotations

import itertools

import numpy as np
import pandas as pd

WEEKS = 52


def seasonal_factor(week_of_year, amp: float, peak_month: int) -> np.ndarray:
    """Multiplicative seasonality with mean ~1 (von Mises shape, peak in the given month)."""
    peak_week = (peak_month - 0.5) * WEEKS / 12
    ang = 2 * np.pi * (np.asarray(week_of_year, float) - peak_week) / WEEKS
    return np.exp(amp * np.cos(ang)) / np.i0(amp)


def daily_seasonal_factor(day_of_year, amp, peak_month) -> np.ndarray:
    return seasonal_factor(np.asarray(day_of_year, float) / 7.0, amp, peak_month)


def synth_history(products: pd.DataFrame, national_packs: pd.Series, years: int = 3,
                  seed: int = 3) -> pd.DataFrame:
    """Weekly national demand history for every SKU (packs)."""
    rng = np.random.default_rng(seed)
    n = years * WEEKS
    t = np.arange(n)
    out = []
    for _, p in products.iterrows():
        annual = float(national_packs.get(p["sku"], 0.0))
        trend = (1 + p["trend_pct"] / 100) ** ((t - n) / WEEKS)  # last year ~ current level
        base = annual / WEEKS * trend * seasonal_factor(t % WEEKS, p["season_amp"], p["season_peak_month"])
        noise = rng.lognormal(-0.5 * p["demand_cv"] ** 2, p["demand_cv"], n)
        out.append(pd.DataFrame({"sku": p["sku"], "week": t, "packs": base * noise}))
    return pd.concat(out, ignore_index=True)


def holt_winters(y: np.ndarray, alpha: float, beta: float, gamma: float, h: int,
                 m: int = WEEKS) -> tuple[np.ndarray, np.ndarray]:
    """Additive Holt-Winters. Returns (in-sample one-step fitted, h-step forecast)."""
    y = np.asarray(y, float)
    level = y[:m].mean()
    trend = (y[m:2 * m].mean() - y[:m].mean()) / m if len(y) >= 2 * m else 0.0
    season = list(y[:m] - level)
    fitted = np.full(len(y), np.nan)
    for i in range(len(y)):
        s = season[i % m] if i >= m else season[i]
        if i >= m:
            fitted[i] = level + trend + s
        if i >= m:
            prev_level = level
            level = alpha * (y[i] - s) + (1 - alpha) * (level + trend)
            trend = beta * (level - prev_level) + (1 - beta) * trend
            season[i % m] = gamma * (y[i] - level) + (1 - gamma) * s
    fc = np.array([level + (k + 1) * trend + season[(len(y) + k) % m] for k in range(h)])
    return fitted, fc


def fit_holt_winters(y: np.ndarray, h: int, log: bool = False) -> dict:
    """Grid search on one-step SSE; returns params, fitted values and forecast.

    log=True fits on log(y), i.e. multiplicative seasonality - much better for
    strongly seasonal products such as flu vaccine and antivirals.
    """
    z = np.log(np.maximum(y, 1e-6)) if log else np.asarray(y, float)
    best = None
    for a, b, g in itertools.product((0.02, 0.05, 0.15, 0.3, 0.5), (0.0, 0.01, 0.05), (0.05, 0.15, 0.3, 0.5)):
        fitted, _ = holt_winters(z, a, b, g, 0)
        err = np.nansum((z - fitted) ** 2)
        if best is None or err < best[0]:
            best = (err, a, b, g)
    _, a, b, g = best
    fitted, fc = holt_winters(z, a, b, g, h)
    resid_sd = float(np.nanstd(z - fitted))
    if log:
        fc = np.exp(fc)
        fitted = np.exp(fitted)
    return {"alpha": a, "beta": b, "gamma": g, "fitted": fitted, "forecast": fc,
            "resid_sd": resid_sd, "model": "multiplicative" if log else "additive"}


def _interval(fit: dict, h: int) -> tuple[np.ndarray, np.ndarray]:
    # Holt-Winters h-step variance ~ sigma^2 * (1 + (h-1) * alpha^2 * (1 + h*beta)), seasonal terms ignored
    k = np.arange(1, h + 1)
    w = 1.96 * fit["resid_sd"] * np.sqrt(1 + (k - 1) * fit["alpha"] ** 2 * (1 + k * fit["beta"]))
    if fit["model"] == "multiplicative":
        return fit["forecast"] * np.exp(-w), fit["forecast"] * np.exp(w)
    return np.maximum(fit["forecast"] - w, 0), fit["forecast"] + w


def forecast_all(history: pd.DataFrame, horizon: int = 26, holdout: int = 13) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Forecast every SKU; back-test accuracy on the last `holdout` weeks.

    Returns (forecast table, accuracy table).
    """
    fc_rows, acc_rows = [], []
    for sku, g in history.groupby("sku", sort=False):
        y = g.sort_values("week")["packs"].to_numpy()
        actual = y[-holdout:]
        best = None
        for log in (False, True):           # pick additive vs multiplicative by back-test
            bt = fit_holt_winters(y[:-holdout], holdout, log=log)
            pred = np.maximum(bt["forecast"], 0)
            wape = float(np.sum(np.abs(actual - pred)) / np.sum(actual))
            if best is None or wape < best[0]:
                best = (wape, log, pred)
        wape, log, pred = best
        mape = float(np.mean(np.abs(actual - pred) / np.maximum(actual, 1e-9)))
        bias = float((pred.sum() - actual.sum()) / actual.sum())
        fit = fit_holt_winters(y, horizon, log=log)
        lo, hi = _interval(fit, horizon)
        last = int(g["week"].max())
        fc_rows.append(pd.DataFrame({
            "sku": sku, "week": np.arange(last + 1, last + 1 + horizon),
            "forecast": np.maximum(fit["forecast"], 0), "lo95": lo, "hi95": hi}))
        acc_rows.append({"sku": sku, "model": fit["model"], "mape": mape, "wape": wape, "bias": bias,
                         "alpha": fit["alpha"], "beta": fit["beta"], "gamma": fit["gamma"]})
    return pd.concat(fc_rows, ignore_index=True), pd.DataFrame(acc_rows)
