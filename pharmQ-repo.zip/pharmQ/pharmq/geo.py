"""Geographic helpers."""
from __future__ import annotations

import numpy as np

EARTH_RADIUS_MI = 3958.8
ROAD_CIRCUITY = 1.20  # road miles are ~20% longer than great-circle miles


def haversine_miles(lat1, lon1, lat2, lon2) -> np.ndarray:
    """Great-circle distance in miles. Accepts scalars or broadcastable arrays."""
    lat1, lon1, lat2, lon2 = map(np.radians, (lat1, lon1, lat2, lon2))
    a = np.sin((lat2 - lat1) / 2) ** 2 + np.cos(lat1) * np.cos(lat2) * np.sin((lon2 - lon1) / 2) ** 2
    return 2 * EARTH_RADIUS_MI * np.arcsin(np.sqrt(np.clip(a, 0, 1)))


def distance_matrix(lat_a, lon_a, lat_b, lon_b, circuity: float = ROAD_CIRCUITY) -> np.ndarray:
    """Matrix of road-equivalent miles between point sets A (rows) and B (cols)."""
    la = np.asarray(lat_a, float)[:, None]
    oa = np.asarray(lon_a, float)[:, None]
    lb = np.asarray(lat_b, float)[None, :]
    ob = np.asarray(lon_b, float)[None, :]
    return haversine_miles(la, oa, lb, ob) * circuity


def transit_days(miles, mode) -> np.ndarray:
    """Rough transit time: ground ~500 mi/day + 1 day handling; air 1-2 days."""
    miles = np.asarray(miles, float)
    ground = 1 + np.ceil(miles / 500.0)
    air = np.where(miles > 1500, 2.0, 1.0)
    return np.where(np.asarray(mode) == "air", air, ground)
