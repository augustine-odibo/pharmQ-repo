"""Inventory policy per DC and SKU: safety stock, reorder point, order quantity (EOQ capped by shelf life)."""
from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.stats import norm

from .config import Config
from .data import Network
from .geo import distance_matrix


def dc_sku_demand(net: Network, lanes: pd.DataFrame) -> pd.DataFrame:
    """Annual demand each open DC must supply, per SKU."""
    route = lanes[["zone_id", "handling", "site_id"]]
    d = net.demand.merge(route, on=["zone_id", "handling"], how="inner")
    return d.groupby(["site_id", "sku"], as_index=False)["annual_packs"].sum()


def inventory_policy(net: Network, lanes: pd.DataFrame, cfg: Config) -> pd.DataFrame:
    dd = dc_sku_demand(net, lanes)
    p = net.products.set_index("sku")
    s = net.sites.set_index("site_id")
    pl = net.plants.set_index("plant_id")
    z = norm.ppf(cfg.service_level)

    df = dd.join(p, on="sku")
    # replenishment lead time = plant lead time + plant -> DC transit (~500 mi/day, FTL)
    miles = distance_matrix(pl.loc[df["primary_plant"], "lat"], pl.loc[df["primary_plant"], "lon"],
                            s.loc[df["site_id"], "lat"], s.loc[df["site_id"], "lon"]).diagonal()
    df["lead_time"] = df["lead_time_days"] + np.ceil(miles / 500.0)
    mu = df["annual_packs"] / 365.0
    # demand_cv is weekly; weekly sd = 7*mu*cv, daily sd = weekly sd / sqrt(7) = sqrt(7)*mu*cv
    sd_daily = mu * df["demand_cv"] * np.sqrt(7)
    P = df["lead_time"] + cfg.review_period_days
    df["daily_demand"] = mu
    df["safety_stock"] = z * np.sqrt(P * sd_daily ** 2 + mu ** 2 * df["lead_time_sd"] ** 2)
    peak = np.exp(df["season_amp"]) / np.i0(df["season_amp"])  # max of the seasonal curve
    df["peak_factor"] = peak
    df["safety_stock_peak"] = z * np.sqrt(P * (sd_daily * peak) ** 2 + (mu * peak) ** 2 * df["lead_time_sd"] ** 2)
    df["reorder_point"] = mu * df["lead_time"] + df["safety_stock"]
    df["reorder_point_peak"] = mu * peak * df["lead_time"] + df["safety_stock_peak"]
    h = cfg.holding_rate * df["unit_cost"]
    eoq = np.sqrt(2 * df["annual_packs"] * cfg.order_cost_usd / h)
    shelf_cap = mu * df["shelf_life_days"] * cfg.max_shelf_life_share
    df["order_qty"] = np.maximum(np.minimum(eoq, shelf_cap), mu * cfg.review_period_days)
    df["shelf_life_capped"] = eoq > shelf_cap
    df["avg_inventory"] = df["order_qty"] / 2 + df["safety_stock"]
    df["inventory_value_usd"] = df["avg_inventory"] * df["unit_cost"]
    df["days_of_supply"] = df["avg_inventory"] / mu
    df["orders_per_year"] = df["annual_packs"] / df["order_qty"]
    df["holding_cost_usd"] = df["avg_inventory"] * h
    df["ordering_cost_usd"] = df["orders_per_year"] * cfg.order_cost_usd
    cols = ["site_id", "sku", "name", "handling", "annual_packs", "daily_demand", "lead_time",
            "safety_stock", "reorder_point", "safety_stock_peak", "reorder_point_peak", "peak_factor",
            "order_qty", "shelf_life_capped", "avg_inventory", "inventory_value_usd", "days_of_supply",
            "orders_per_year", "holding_cost_usd", "ordering_cost_usd", "unit_cost", "demand_cv",
            "lead_time_sd", "shelf_life_days", "season_amp", "season_peak_month",
            "primary_plant", "backup_plant"]
    return df[cols].reset_index(drop=True)
