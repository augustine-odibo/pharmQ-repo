"""Distribution network design: which DCs to open and which DC serves each zone.

Model (facility location, single-sourced per zone and handling class):

    min  sum_d F_d y_d + sum_{z,k,d} c_{zkd} x_{zkd}
    s.t. sum_d x_{zkd} = 1                      for every zone z, handling class k
         x_{zkd} <= y_d,  x_{zkd} = 0 if d cannot handle k (cold chain / DEA vault)
         sum_{z,k} q_{zk} x_{zkd} <= Cap_d y_d
         min_dcs <= sum_d y_d <= max_dcs, forced open / closed sites

c_{zkd} = q_{zk} * (outbound miles * rate_k * mode multiplier + inbound cost per pack at d).
Solved exactly with SciPy's HiGHS MILP, otherwise with a greedy + swap heuristic
(identical to the heuristic used by the R package).
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

from .config import Config
from .data import HANDLING_CLASSES, Network
from .geo import distance_matrix, transit_days

BIG = 1e18


@dataclass
class CostModel:
    keys: pd.DataFrame          # one row per (zone, handling) with demand q
    site_ids: list[str]
    cost: np.ndarray            # [n_keys, n_sites] annual $ (BIG if infeasible)
    miles: np.ndarray           # [n_keys, n_sites]
    mode: np.ndarray            # [n_keys, n_sites] 'ground' | 'air'
    fixed: np.ndarray           # [n_sites] annual $
    capacity: np.ndarray        # [n_sites] packs / year
    q: np.ndarray               # [n_keys] packs / year


def build_cost_model(net: Network, cfg: Config) -> CostModel:
    zones, sites, plants, products = net.zones, net.sites, net.plants, net.products
    keys = (net.demand.groupby(["zone_id", "handling"], as_index=False)["annual_packs"].sum()
            .rename(columns={"annual_packs": "q"}))
    keys = keys[keys["q"] > 0].reset_index(drop=True)
    zk = keys.merge(zones[["zone_id", "lat", "lon", "state", "island"]], on="zone_id", how="left")

    miles = distance_matrix(zk["lat"], zk["lon"], sites["lat"], sites["lon"])
    same_state = zk["state"].to_numpy()[:, None] == sites["state"].to_numpy()[None, :]
    island = zk["island"].to_numpy()[:, None] == 1
    site_island = sites["state"].isin(zones.loc[zones["island"] == 1, "state"]).to_numpy()[None, :]
    is_cold = (zk["handling"] == "cold").to_numpy()[:, None]
    ground_limit = np.where(is_cold, cfg.max_cold_ground_miles, cfg.max_ground_miles)
    # air when crossing water (island zone or island DC in another state) or beyond ground limit
    air = ((island | site_island) & ~same_state) | (miles > ground_limit)
    mode = np.where(air, "air", "ground")

    rate = zk["handling"].map(cfg.rate_for).to_numpy()[:, None]
    mult = np.where(air, cfg.air_multiplier, 1.0)

    # inbound: volume-weighted distance from each DC to the SKU's primary plant, per class
    plant_xy = plants.set_index("plant_id")[["lat", "lon"]]
    inbound = np.zeros((len(HANDLING_CLASSES), len(sites)))
    for i, k in enumerate(HANDLING_CLASSES):
        sk = net.demand[net.demand["handling"] == k].groupby("sku")["annual_packs"].sum()
        if sk.empty:
            continue
        pp = products.set_index("sku").loc[sk.index, "primary_plant"]
        pm = distance_matrix(plant_xy.loc[pp, "lat"], plant_xy.loc[pp, "lon"], sites["lat"], sites["lon"])
        w = (sk / sk.sum()).to_numpy()[:, None]
        inbound[i] = (pm * w).sum(axis=0) * cfg.rate_inbound
    cls_idx = zk["handling"].map({k: i for i, k in enumerate(HANDLING_CLASSES)}).to_numpy()

    q = zk["q"].to_numpy()
    cost = q[:, None] * (miles * rate * mult + inbound[cls_idx])
    can_cold = sites["cold_chain"].astype(bool).to_numpy()[None, :]
    can_ctrl = sites["dea_vault"].astype(bool).to_numpy()[None, :]
    feasible = np.where(is_cold, can_cold, True) & np.where(
        (zk["handling"] == "controlled").to_numpy()[:, None], can_ctrl, True)
    cost = np.where(feasible, cost, BIG)

    return CostModel(keys=zk, site_ids=sites["site_id"].tolist(), cost=cost, miles=miles,
                     mode=mode, fixed=sites["fixed_cost_musd"].to_numpy() * 1e6,
                     capacity=sites["capacity_mpacks"].to_numpy() * 1e6, q=q)


# ----------------------------------------------------------------------------- heuristic
UNSERVED_PENALTY = 50.0  # $ per pack left unassigned (only used while searching)


def _assign(cm: CostModel, open_mask: np.ndarray) -> tuple[np.ndarray, float, bool]:
    """Capacity-aware greedy assignment by regret.

    Returns (site index per key or -1, total cost incl. penalties, feasible flag).
    """
    idx = np.flatnonzero(open_mask)
    if idx.size == 0:
        return np.full(len(cm.q), -1), float(cm.q.sum() * UNSERVED_PENALTY), False
    c = cm.cost[:, idx]
    srt = np.sort(c, axis=1)
    regret = np.minimum(srt[:, 1] - srt[:, 0], 1e15) if idx.size > 1 else srt[:, 0]
    remaining = cm.capacity[idx].astype(float).copy()
    assign = np.full(len(cm.q), -1)
    total = float(cm.fixed[idx].sum())
    feasible = True
    for r in np.argsort(-regret):
        for j in np.argsort(c[r]):
            if c[r, j] >= BIG:
                break
            if remaining[j] >= cm.q[r]:
                assign[r] = idx[j]
                remaining[j] -= cm.q[r]
                total += c[r, j]
                break
        if assign[r] < 0:
            feasible = False
            total += cm.q[r] * UNSERVED_PENALTY
    return assign, total, feasible


def solve_heuristic(cm: CostModel, cfg: Config) -> np.ndarray:
    forced_open = np.isin(cm.site_ids, cfg.force_open)
    closed = np.isin(cm.site_ids, cfg.force_closed)
    open_mask = forced_open.copy()
    _, best, _ = _assign(cm, open_mask)
    # greedy add: open the single site that lowers cost most; stop when nothing helps
    while open_mask.sum() < cfg.max_dcs:
        cand = None
        for j in np.flatnonzero(~open_mask & ~closed):
            trial = open_mask.copy(); trial[j] = True
            _, val, _ = _assign(cm, trial)
            if cand is None or val < cand[1]:
                cand = (j, val)
        if cand is None or (cand[1] >= best and open_mask.sum() >= cfg.min_dcs):
            break
        open_mask[cand[0]] = True
        best = cand[1]
    # swap / drop improvement
    improved = True
    while improved:
        improved = False
        for j in np.flatnonzero(open_mask & ~forced_open):
            if open_mask.sum() > cfg.min_dcs:
                trial = open_mask.copy(); trial[j] = False
                _, val, _ = _assign(cm, trial)
                if val < best - 1e-6:
                    open_mask, best, improved = trial, val, True
                    continue
            for i in np.flatnonzero(~open_mask & ~closed):
                trial = open_mask.copy(); trial[j] = False; trial[i] = True
                _, val, _ = _assign(cm, trial)
                if val < best - 1e-6:
                    open_mask, best, improved = trial, val, True
                    break
            if improved:
                break
    return open_mask


# ----------------------------------------------------------------------------- MILP
def solve_milp(cm: CostModel, cfg: Config) -> tuple[np.ndarray, np.ndarray] | None:
    """Exact MILP with SciPy's HiGHS solver (no extra install needed)."""
    from scipy.optimize import Bounds, LinearConstraint, milp
    from scipy.sparse import coo_matrix, vstack

    n_k, n_s = cm.cost.shape
    rr, jj = np.nonzero(cm.cost < BIG)
    n_p = len(rr)
    nv = n_s + n_p                      # [y_0..y_{s-1}, x_pairs...]
    c = np.concatenate([cm.fixed, cm.cost[rr, jj]]) / 1e6   # scale to $M for numerics
    xi = n_s + np.arange(n_p)

    A_assign = coo_matrix((np.ones(n_p), (rr, xi)), shape=(n_k, nv))
    A_link = coo_matrix((np.concatenate([np.ones(n_p), -np.ones(n_p)]),
                         (np.concatenate([np.arange(n_p)] * 2), np.concatenate([xi, jj]))), shape=(n_p, nv))
    A_cap = coo_matrix((np.concatenate([cm.q[rr], -cm.capacity]),
                        (np.concatenate([jj, np.arange(n_s)]), np.concatenate([xi, np.arange(n_s)]))),
                       shape=(n_s, nv))
    A_cnt = coo_matrix((np.ones(n_s), (np.zeros(n_s, int), np.arange(n_s))), shape=(1, nv))
    A = vstack([A_assign, A_link, A_cap, A_cnt]).tocsr()
    lb = np.concatenate([np.ones(n_k), np.full(n_p, -np.inf), np.full(n_s, -np.inf), [cfg.min_dcs]])
    ub = np.concatenate([np.ones(n_k), np.zeros(n_p), np.zeros(n_s), [cfg.max_dcs]])

    lo, hi = np.zeros(nv), np.ones(nv)
    ids = np.array(cm.site_ids)
    lo[:n_s][np.isin(ids, cfg.force_open)] = 1
    hi[:n_s][np.isin(ids, cfg.force_closed)] = 0
    res = milp(c, constraints=LinearConstraint(A, lb, ub), integrality=np.ones(nv),
               bounds=Bounds(lo, hi), options={"time_limit": cfg.time_limit_s, "mip_rel_gap": 1e-4})
    if res.x is None:
        return None
    xs = res.x[n_s:] > 0.5
    assign = np.full(n_k, -1)
    assign[rr[xs]] = jj[xs]
    return res.x[:n_s] > 0.5, assign


# ----------------------------------------------------------------------------- results
@dataclass
class NetworkSolution:
    open_sites: pd.DataFrame
    lanes: pd.DataFrame
    kpis: dict
    solver: str


def optimize_network(net: Network, cfg: Config) -> NetworkSolution:
    cm = build_cost_model(net, cfg)
    sol, used = None, "heuristic"
    if cfg.solver in ("auto", "milp"):
        sol, used = solve_milp(cm, cfg), "milp"
        if sol is None and cfg.solver == "milp":
            raise RuntimeError("MILP solve failed (problem infeasible or time limit too short)")
    if sol is not None:
        open_mask, assign = sol
        feasible = (assign >= 0).all()
    else:
        used = "heuristic"
        open_mask = solve_heuristic(cm, cfg)
        assign, _, feasible = _assign(cm, open_mask)
    if not feasible:
        raise RuntimeError("No feasible network: add capacity, cold-chain or DEA-licensed sites, "
                           "or relax forced closures / max_dcs.")
    return _summarize(net, cm, open_mask, assign, used)


def _summarize(net, cm, open_mask, assign, solver) -> NetworkSolution:
    r = np.arange(len(cm.q))
    lanes = cm.keys[["zone_id", "state", "handling", "q", "lat", "lon"]].copy()
    lanes["site_id"] = np.array(cm.site_ids)[assign]
    lanes["miles"] = cm.miles[r, assign]
    lanes["mode"] = cm.mode[r, assign]
    lanes["annual_cost_usd"] = cm.cost[r, assign]
    lanes["transit_days"] = transit_days(lanes["miles"], lanes["mode"])
    lanes = lanes.rename(columns={"q": "annual_packs", "lat": "zone_lat", "lon": "zone_lon"})
    s = net.sites.set_index("site_id")
    lanes["dc_lat"] = lanes["site_id"].map(s["lat"])
    lanes["dc_lon"] = lanes["site_id"].map(s["lon"])

    opened = net.sites[open_mask].copy()
    load = lanes.groupby("site_id")["annual_packs"].sum()
    opened["throughput_mpacks"] = opened["site_id"].map(load).fillna(0) / 1e6
    opened["utilization"] = opened["throughput_mpacks"] / opened["capacity_mpacks"]
    opened["zones_served"] = opened["site_id"].map(lanes.groupby("site_id")["zone_id"].nunique()).fillna(0).astype(int)
    pop = net.zones.set_index("zone_id")["population"]
    amb = lanes[lanes["handling"] == "ambient"]
    w = amb["annual_packs"]
    fixed = float(cm.fixed[open_mask].sum())
    transport = float(lanes["annual_cost_usd"].sum())
    kpis = {
        "dcs_open": int(open_mask.sum()),
        "fixed_cost_usd": fixed,
        "transport_cost_usd": transport,
        "total_cost_usd": fixed + transport,
        "cost_per_pack_usd": (fixed + transport) / float(lanes["annual_packs"].sum()),
        "avg_miles": float(np.average(lanes["miles"], weights=lanes["annual_packs"])),
        "pct_pop_next_day": float(pop[amb.loc[amb["transit_days"] <= 2, "zone_id"]].sum() / pop.sum()),
        "pct_demand_within_500mi": float(w[amb["miles"] <= 500].sum() / w.sum()) if len(w) else 0.0,
        "pct_volume_air": float(lanes.loc[lanes["mode"] == "air", "annual_packs"].sum() / lanes["annual_packs"].sum()),
        "max_utilization": float(opened["utilization"].max()),
    }
    return NetworkSolution(open_sites=opened.reset_index(drop=True), lanes=lanes, kpis=kpis, solver=solver)
