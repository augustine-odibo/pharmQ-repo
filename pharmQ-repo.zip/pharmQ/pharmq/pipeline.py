"""End-to-end pharmQ pipeline: data -> forecast -> network design -> inventory -> simulation -> risk."""
from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from pathlib import Path

import pandas as pd

from .config import Config
from .data import Network, build_network
from .forecast import forecast_all, synth_history
from .inventory import inventory_policy
from .network import NetworkSolution, optimize_network
from .risk import shortage_risk
from .simulation import Outage, simulate


@dataclass
class Results:
    config: Config
    network: Network
    solution: NetworkSolution
    history: pd.DataFrame
    forecast: pd.DataFrame
    accuracy: pd.DataFrame
    policy: pd.DataFrame
    sim: pd.DataFrame
    risk: pd.DataFrame
    timings: dict = field(default_factory=dict)

    def summary(self) -> dict:
        sim = self.sim
        return {
            **self.network.summary(),
            **self.solution.kpis,
            "solver": self.solution.solver,
            "inventory_value_usd": float(self.policy["inventory_value_usd"].sum()),
            "fill_rate": float(sim["filled"].sum() / sim["demand"].sum()),
            "expired_value_usd": float(sim["expired_value_usd"].sum()),
            "high_risk_skus": int((self.risk["risk_tier"] == "High").sum()),
            "forecast_wape": float(self.accuracy["wape"].mean()),
            "timings_s": self.timings,
        }

    def export(self, outdir: str | Path) -> Path:
        out = Path(outdir)
        out.mkdir(parents=True, exist_ok=True)
        tables = {
            "zones": self.network.zones, "demand": self.network.demand,
            "open_dcs": self.solution.open_sites, "lanes": self.solution.lanes,
            "forecast": self.forecast, "forecast_accuracy": self.accuracy,
            "inventory_policy": self.policy, "simulation": self.sim, "shortage_risk": self.risk,
        }
        for name, df in tables.items():
            df.to_csv(out / f"{name}.csv", index=False)
        (out / "summary.json").write_text(json.dumps(self.summary(), indent=2, default=float))
        (out / "config.json").write_text(json.dumps(self.config.to_dict(), indent=2))
        return out


def run(cfg: Config | None = None, network: Network | None = None,
        outage: Outage | None = None, forecast_horizon: int = 26) -> Results:
    cfg = cfg or Config()
    t = {}
    t0 = time.perf_counter()
    net = network or build_network(cfg.zones_per_state, cfg.seed, cfg.demand_multiplier,
                                   cfg.sku_multipliers, include_states=cfg.include_states,
                                   local_variation=cfg.local_variation)
    t["data"] = time.perf_counter() - t0

    t0 = time.perf_counter()
    national = net.demand.groupby("sku")["annual_packs"].sum()
    history = synth_history(net.products, national, seed=cfg.seed)
    fc, acc = forecast_all(history, horizon=forecast_horizon)
    t["forecast"] = time.perf_counter() - t0

    t0 = time.perf_counter()
    sol = optimize_network(net, cfg)
    t["network"] = time.perf_counter() - t0

    t0 = time.perf_counter()
    policy = inventory_policy(net, sol.lanes, cfg)
    sim = simulate(policy, cfg, outage)
    risk = shortage_risk(net.products, sim, cfg.service_level)
    t["inventory_sim_risk"] = time.perf_counter() - t0
    return Results(cfg, net, sol, history, fc, acc, policy, sim, risk, {k: round(v, 3) for k, v in t.items()})
