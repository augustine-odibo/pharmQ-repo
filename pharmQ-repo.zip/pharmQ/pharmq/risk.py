"""Shortage-risk scoring per SKU (0 = safe, 100 = critical)."""
from __future__ import annotations

import numpy as np
import pandas as pd

WEIGHTS = {
    "single_source": 0.25,
    "service_gap": 0.30,
    "demand_volatility": 0.15,
    "lead_time_variability": 0.10,
    "handling_complexity": 0.10,
    "shelf_life_pressure": 0.10,
}


def shortage_risk(products: pd.DataFrame, sim: pd.DataFrame, target_fill: float = 0.98) -> pd.DataFrame:
    agg = sim.groupby("sku").agg(demand=("demand", "sum"), filled=("filled", "sum"),
                                 expired=("expired_packs", "sum"),
                                 stockout_days=("stockout_days", "max")).reset_index()
    agg["fill_rate"] = agg["filled"] / agg["demand"]
    df = products.merge(agg, on="sku", how="left").fillna({"fill_rate": 1.0, "expired": 0, "demand": 0})
    comp = pd.DataFrame({
        "single_source": (df["backup_plant"].astype(str).str.len() == 0).astype(float),
        "service_gap": np.clip((target_fill - df["fill_rate"]) / 0.10, 0, 1),
        "demand_volatility": np.clip((df["demand_cv"] + df["season_amp"] / 3) / 0.6, 0, 1),
        "lead_time_variability": np.clip(df["lead_time_sd"] / df["lead_time_days"] / 0.35, 0, 1),
        "handling_complexity": df["handling"].map({"ambient": 0.0, "controlled": 0.7, "cold": 1.0}),
        "shelf_life_pressure": np.clip(np.where(df["demand"] > 0, df["expired"] / np.maximum(df["demand"], 1) / 0.02, 0)
                                       + (df["shelf_life_days"] < 400) * 0.5, 0, 1),
    })
    df["risk_score"] = 100 * sum(comp[k] * w for k, w in WEIGHTS.items())
    df["risk_tier"] = pd.cut(df["risk_score"], [-1, 30, 55, 101], labels=["Low", "Medium", "High"]).astype(str)
    top = comp.idxmax(axis=1)
    df["main_driver"] = top.str.replace("_", " ")
    out = pd.concat([df[["sku", "name", "handling", "fill_rate", "risk_score", "risk_tier", "main_driver"]],
                     comp.add_prefix("c_")], axis=1)
    return out.sort_values("risk_score", ascending=False).reset_index(drop=True)
