"""Daily stochastic inventory simulation for every DC x SKU.

Continuous review (s, Q) with a seasonally adjusted reorder point, random demand and
lead times, lot-level expiry with FEFO picking, and optional plant outages that force
orders to the backup plant (or delay them when the SKU is single-sourced).
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

from .config import Config
from .forecast import daily_seasonal_factor


@dataclass
class Outage:
    plant_id: str
    start_day: int = 30
    duration_days: int = 60
    backup_lead_time_multiplier: float = 1.3


def simulate_one(row: pd.Series, cfg: Config, rng: np.random.Generator,
                 outage: Outage | None = None, start_doy: int = 1) -> dict:
    days = cfg.sim_days
    mu = row["daily_demand"]
    cv_d = row["demand_cv"] * np.sqrt(7)  # weekly CV -> daily CV (independent days)
    lt, lt_sd = row["lead_time"], row["lead_time_sd"]
    Q, ss = row["order_qty"], row["safety_stock"]
    shelf = row["shelf_life_days"]
    doy = (start_doy + np.arange(days + 120)) % 365
    f = daily_seasonal_factor(doy, row["season_amp"], row["season_peak_month"])

    # initial stock: one cycle + safety stock, fresh-ish (70% shelf life remaining)
    lots = [[float(Q / 2 + ss * f[0]), shelf * 0.7]]  # [qty, days to expiry]
    pipeline: list[tuple[int, float]] = []           # (arrival day, qty)
    demand_tot = filled_tot = expired = 0.0
    stockout_days = 0
    onhand_sum = 0.0
    orders = 0
    for t in range(days):
        # receive
        arrived = [q for d, q in pipeline if d == t]
        pipeline = [(d, q) for d, q in pipeline if d != t]
        for q in arrived:
            lots.append([q, shelf * rng.uniform(0.8, 0.95)])
        # demand (lognormal around seasonal mean)
        m = mu * f[t]
        dem = m * rng.lognormal(-0.5 * cv_d ** 2, cv_d) if m > 0 else 0.0
        demand_tot += dem
        need = dem
        lots.sort(key=lambda x: x[1])  # FEFO
        for lot in lots:
            take = min(lot[0], need)
            lot[0] -= take
            need -= take
            if need <= 1e-9:
                break
        filled_tot += dem - need
        if need > 1e-6:
            stockout_days += 1
        # age lots, write off expired
        for lot in lots:
            lot[1] -= 1
        expired += sum(lot[0] for lot in lots if lot[1] <= 0)
        lots = [lot for lot in lots if lot[1] > 0 and lot[0] > 1e-9]
        on_hand = sum(lot[0] for lot in lots)
        onhand_sum += on_hand
        # reorder decision with seasonally adjusted reorder point
        position = on_hand + sum(q for _, q in pipeline)
        horizon = f[t: t + int(lt) + 1]
        rop = mu * horizon.mean() * lt + ss * f[t]
        if position <= rop:
            n = int(np.ceil((rop - position) / Q)) if position < rop - Q else 1
            this_lt = max(1.0, rng.normal(lt, lt_sd))
            if outage and row["primary_plant"] == outage.plant_id and \
                    outage.start_day <= t < outage.start_day + outage.duration_days:
                if row["backup_plant"]:
                    this_lt *= outage.backup_lead_time_multiplier
                else:
                    this_lt += outage.start_day + outage.duration_days - t
            pipeline.append((t + int(round(this_lt)), n * Q))
            orders += 1
    return {
        "site_id": row["site_id"], "sku": row["sku"],
        "demand": demand_tot, "filled": filled_tot,
        "fill_rate": filled_tot / demand_tot if demand_tot else 1.0,
        "stockout_days": stockout_days, "expired_packs": expired,
        "expired_value_usd": expired * row["unit_cost"],
        "avg_on_hand": onhand_sum / days, "orders": orders,
    }


def simulate(policy: pd.DataFrame, cfg: Config, outage: Outage | None = None) -> pd.DataFrame:
    rng = np.random.default_rng(cfg.sim_seed)
    rows = [simulate_one(r, cfg, rng, outage) for _, r in policy.iterrows()]
    return pd.DataFrame(rows)
