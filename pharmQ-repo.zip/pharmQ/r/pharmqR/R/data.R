# pharmqR - data loading, configuration and network generation

HANDLING_CLASSES <- c("ambient", "cold", "controlled")

REQUIRED_COLUMNS <- list(
  states   = c("state", "name", "region", "population", "lat", "lon", "island"),
  dc_sites = c("site_id", "city", "state", "lat", "lon", "fixed_cost_musd",
               "capacity_mpacks", "cold_chain", "dea_vault"),
  plants   = c("plant_id", "name", "state", "lat", "lon"),
  products = c("sku", "name", "therapeutic_class", "handling", "unit_cost",
               "annual_packs_per_1k", "demand_cv", "season_amp", "season_peak_month",
               "trend_pct", "shelf_life_days", "lead_time_days", "lead_time_sd",
               "primary_plant", "backup_plant")
)

#' Folder holding the bundled reference CSVs
pq_data_dir <- function() {
  d <- system.file("extdata", package = "pharmqR")
  if (nzchar(d)) return(d)
  # running from source (e.g. source("R/...")): look relative to the working dir
  for (cand in c("inst/extdata", "../inst/extdata", "../pharmqR/inst/extdata",
                 "r/pharmqR/inst/extdata", "../../pharmq/data", "pharmq/data")) {
    if (file.exists(file.path(cand, "products.csv"))) return(normalizePath(cand))
  }
  stop("Cannot find pharmQ reference data")
}

#' Validate a user-supplied table
pq_validate <- function(df, table) {
  missing <- setdiff(REQUIRED_COLUMNS[[table]], names(df))
  if (length(missing)) stop(sprintf("Table '%s' is missing columns: %s", table, paste(missing, collapse = ", ")))
  if (table == "products") {
    bad <- setdiff(unique(df$handling), HANDLING_CLASSES)
    if (length(bad)) stop("Unknown handling class(es): ", paste(bad, collapse = ", "))
    df$backup_plant[is.na(df$backup_plant)] <- ""
    df$backup_plant <- as.character(df$backup_plant)
  }
  df
}

#' Load a bundled table ("states", "dc_sites", "plants", "products") or your own CSV
pq_load <- function(table, path = NULL) {
  f <- if (is.null(path)) file.path(pq_data_dir(), paste0(table, ".csv")) else path
  pq_validate(utils::read.csv(f, stringsAsFactors = FALSE, na.strings = c("NA")), table)
}

#' Model configuration (same fields and defaults as the Python Config)
pq_config <- function(...) {
  cfg <- list(
    zones_per_state = 1L, seed = 7L, demand_multiplier = 1, include_states = NULL,
    sku_multipliers = list(), local_variation = 0.08,
    solver = "heuristic", min_dcs = 1L, max_dcs = 30L, force_open = character(),
    force_closed = character(),
    rate_ambient = 1e-4, rate_controlled = 1.8e-4, rate_cold = 3.5e-4, rate_inbound = 2e-5,
    air_multiplier = 6, max_ground_miles = 2500, max_cold_ground_miles = 1200,
    service_level = 0.98, order_cost_usd = 450, holding_rate = 0.22, review_period_days = 7,
    max_shelf_life_share = 0.35, sim_days = 365L, sim_seed = 42L
  )
  args <- list(...)
  unknown <- setdiff(names(args), names(cfg))
  if (length(unknown)) stop("Unknown config keys: ", paste(unknown, collapse = ", "))
  cfg[names(args)] <- args
  cfg
}

pq_rate_for <- function(cfg, handling) {
  c(ambient = cfg$rate_ambient, cold = cfg$rate_cold, controlled = cfg$rate_controlled)[handling]
}

#' Split each state into demand zones
pq_build_zones <- function(states, zones_per_state = 1, seed = 7, include = NULL) {
  set.seed(seed)
  if (!is.null(include)) states <- states[states$state %in% include, ]
  out <- list()
  for (i in seq_len(nrow(states))) {
    s <- states[i, ]
    n <- if (s$population < 1e6) 1 else zones_per_state
    w <- if (n > 1) { g <- stats::rgamma(n, 4); g / sum(g) } else 1
    spread <- if (n == 1) 0 else min(2, 0.4 + s$population / 15e6)
    for (j in seq_len(n)) {
      out[[length(out) + 1]] <- data.frame(
        zone_id = paste0(s$state, "-", j), state = s$state, region = s$region,
        population = round(s$population * w[j]),
        lat = s$lat + if (n > 1) stats::rnorm(1, 0, spread * 0.5) else 0,
        lon = s$lon + if (n > 1) stats::rnorm(1, 0, spread) else 0,
        island = s$island,
        pharmacies = max(1, round(s$population * w[j] * 19 / 1e5)),
        stringsAsFactors = FALSE)
    }
  }
  do.call(rbind, out)
}

#' Annual demand per zone and SKU
pq_build_demand <- function(zones, products, seed = 11, demand_multiplier = 1,
                            sku_multipliers = list(), local_variation = 0.08) {
  set.seed(seed)
  d <- merge(zones[, c("zone_id", "state", "population")],
             products[, c("sku", "handling", "unit_cost", "annual_packs_per_1k")], by = NULL)
  local <- if (local_variation > 0) stats::rlnorm(nrow(d), 0, local_variation) else rep(1, nrow(d))
  mult <- vapply(d$sku, function(s) if (!is.null(sku_multipliers[[s]])) sku_multipliers[[s]] else 1, numeric(1))
  d$annual_packs <- d$population / 1000 * d$annual_packs_per_1k * local * mult * demand_multiplier
  d$annual_value_usd <- d$annual_packs * d$unit_cost
  d <- d[order(d$zone_id, d$sku), c("zone_id", "state", "sku", "handling", "annual_packs", "annual_value_usd")]
  rownames(d) <- NULL
  d
}

#' Assemble the full network (bundled data unless you pass your own tables)
pq_build_network <- function(cfg = pq_config(), states = NULL, sites = NULL, plants = NULL,
                             products = NULL, zones = NULL) {
  states   <- if (is.null(states)) pq_load("states") else pq_validate(states, "states")
  sites    <- if (is.null(sites)) pq_load("dc_sites") else pq_validate(sites, "dc_sites")
  plants   <- if (is.null(plants)) pq_load("plants") else pq_validate(plants, "plants")
  products <- if (is.null(products)) pq_load("products") else pq_validate(products, "products")
  if (is.null(zones)) zones <- pq_build_zones(states, cfg$zones_per_state, cfg$seed, cfg$include_states)
  demand <- pq_build_demand(zones, products, cfg$seed + 4, cfg$demand_multiplier,
                            cfg$sku_multipliers, cfg$local_variation)
  structure(list(zones = zones, sites = sites, plants = plants, products = products, demand = demand),
            class = "pq_network")
}

print.pq_network <- function(x, ...) {
  cat(sprintf("pharmQ network: %d zones, %.0fM people, %d candidate DCs, %d plants, %d SKUs, %.0fM packs/yr\n",
              nrow(x$zones), sum(x$zones$population) / 1e6, nrow(x$sites), nrow(x$plants),
              nrow(x$products), sum(x$demand$annual_packs) / 1e6))
  invisible(x)
}

# ---------------------------------------------------------------- geography
pq_haversine <- function(lat1, lon1, lat2, lon2) {
  r <- pi / 180
  a <- sin((lat2 - lat1) * r / 2)^2 + cos(lat1 * r) * cos(lat2 * r) * sin((lon2 - lon1) * r / 2)^2
  2 * 3958.8 * asin(sqrt(pmin(pmax(a, 0), 1)))
}

#' Road-equivalent miles between point sets (rows = A, cols = B)
pq_distance_matrix <- function(lat_a, lon_a, lat_b, lon_b, circuity = 1.2) {
  outer(seq_along(lat_a), seq_along(lat_b),
        function(i, j) pq_haversine(lat_a[i], lon_a[i], lat_b[j], lon_b[j])) * circuity
}

pq_transit_days <- function(miles, mode) {
  ifelse(mode == "air", ifelse(miles > 1500, 2, 1), 1 + ceiling(miles / 500))
}
