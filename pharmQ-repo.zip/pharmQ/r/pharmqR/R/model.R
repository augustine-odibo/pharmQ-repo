# pharmqR - forecasting, inventory policy, simulation, risk and the end-to-end pipeline

pq_seasonal_factor <- function(week, amp, peak_month) {
  peak_week <- (peak_month - 0.5) * 52 / 12
  exp(amp * cos(2 * pi * (week - peak_week) / 52)) / besselI(amp, 0)
}

#' Weekly national demand history per SKU
pq_synth_history <- function(products, national, years = 3, seed = 3) {
  set.seed(seed)
  n <- years * 52; t <- 0:(n - 1)
  do.call(rbind, lapply(seq_len(nrow(products)), function(i) {
    p <- products[i, ]
    annual <- if (p$sku %in% names(national)) national[[p$sku]] else 0
    trend <- (1 + p$trend_pct / 100)^((t - n) / 52)
    base <- annual / 52 * trend * pq_seasonal_factor(t %% 52, p$season_amp, p$season_peak_month)
    noise <- stats::rlnorm(n, -0.5 * p$demand_cv^2, p$demand_cv)
    data.frame(sku = p$sku, week = t, packs = base * noise, stringsAsFactors = FALSE)
  }))
}

#' Holt-Winters per SKU (stats::HoltWinters); additive vs multiplicative chosen by back-test
pq_forecast <- function(history, horizon = 26, holdout = 13) {
  fc <- list(); acc <- list()
  for (s in unique(history$sku)) {
    y <- history$packs[history$sku == s][order(history$week[history$sku == s])]
    actual <- utils::tail(y, holdout); train <- utils::head(y, -holdout)
    best <- NULL
    for (m in c("additive", "multiplicative")) {
      fit <- tryCatch(suppressWarnings(stats::HoltWinters(stats::ts(train, frequency = 52), seasonal = m)),
                      error = function(e) NULL)
      if (is.null(fit)) next
      pred <- pmax(as.numeric(stats::predict(fit, holdout)), 0)
      wape <- sum(abs(actual - pred)) / sum(actual)
      if (is.null(best) || wape < best$wape) best <- list(model = m, wape = wape, pred = pred)
    }
    fit <- suppressWarnings(stats::HoltWinters(stats::ts(y, frequency = 52), seasonal = best$model))
    p <- stats::predict(fit, horizon, prediction.interval = TRUE)
    last <- max(history$week[history$sku == s])
    fc[[s]] <- data.frame(sku = s, week = last + seq_len(horizon), forecast = pmax(as.numeric(p[, "fit"]), 0),
                          lo95 = pmax(as.numeric(p[, "lwr"]), 0), hi95 = as.numeric(p[, "upr"]))
    acc[[s]] <- data.frame(sku = s, model = best$model,
                           mape = mean(abs(actual - best$pred) / pmax(actual, 1e-9)), wape = best$wape,
                           bias = (sum(best$pred) - sum(actual)) / sum(actual),
                           alpha = unname(fit$alpha), beta = unname(fit$beta), gamma = unname(fit$gamma))
  }
  list(forecast = do.call(rbind, fc), accuracy = do.call(rbind, acc))
}

#' Inventory policy per DC x SKU
pq_inventory_policy <- function(net, lanes, cfg) {
  d <- merge(net$demand, lanes[, c("zone_id", "handling", "site_id")], by = c("zone_id", "handling"))
  dd <- stats::aggregate(annual_packs ~ site_id + sku, data = d, FUN = sum)
  df <- merge(dd, net$products, by = "sku")
  pl <- match(df$primary_plant, net$plants$plant_id); st <- match(df$site_id, net$sites$site_id)
  miles <- pq_haversine(net$plants$lat[pl], net$plants$lon[pl], net$sites$lat[st], net$sites$lon[st]) * 1.2
  z <- stats::qnorm(cfg$service_level)
  df$lead_time <- df$lead_time_days + ceiling(miles / 500)
  mu <- df$annual_packs / 365
  sd_daily <- mu * df$demand_cv * sqrt(7)
  P <- df$lead_time + cfg$review_period_days
  peak <- exp(df$season_amp) / besselI(df$season_amp, 0)
  df$daily_demand <- mu
  df$safety_stock <- z * sqrt(P * sd_daily^2 + mu^2 * df$lead_time_sd^2)
  df$peak_factor <- peak
  df$safety_stock_peak <- z * sqrt(P * (sd_daily * peak)^2 + (mu * peak)^2 * df$lead_time_sd^2)
  df$reorder_point <- mu * df$lead_time + df$safety_stock
  df$reorder_point_peak <- mu * peak * df$lead_time + df$safety_stock_peak
  h <- cfg$holding_rate * df$unit_cost
  eoq <- sqrt(2 * df$annual_packs * cfg$order_cost_usd / h)
  shelf_cap <- mu * df$shelf_life_days * cfg$max_shelf_life_share
  df$order_qty <- pmax(pmin(eoq, shelf_cap), mu * cfg$review_period_days)
  df$shelf_life_capped <- eoq > shelf_cap
  df$avg_inventory <- df$order_qty / 2 + df$safety_stock
  df$inventory_value_usd <- df$avg_inventory * df$unit_cost
  df$days_of_supply <- df$avg_inventory / mu
  df$orders_per_year <- df$annual_packs / df$order_qty
  df$holding_cost_usd <- df$avg_inventory * h
  df$ordering_cost_usd <- df$orders_per_year * cfg$order_cost_usd
  df <- df[order(df$site_id, df$sku), ]; rownames(df) <- NULL
  df
}

#' Plant outage definition for the simulation
pq_outage <- function(plant_id, start_day = 30, duration_days = 60, backup_lead_time_multiplier = 1.3) {
  list(plant_id = plant_id, start_day = start_day, duration_days = duration_days,
       backup_lead_time_multiplier = backup_lead_time_multiplier)
}

pq_simulate_one <- function(row, cfg, outage = NULL, start_doy = 1) {
  days <- cfg$sim_days; mu <- row$daily_demand; cv_d <- row$demand_cv * sqrt(7)
  lt <- row$lead_time; lt_sd <- row$lead_time_sd; Q <- row$order_qty; ss <- row$safety_stock
  shelf <- row$shelf_life_days
  doy <- (start_doy + 0:(days + 119)) %% 365
  f <- pq_seasonal_factor(doy / 7, row$season_amp, row$season_peak_month)
  lot_q <- Q / 2 + ss * f[1]; lot_e <- shelf * 0.7
  pipe_d <- integer(); pipe_q <- numeric()
  demand_tot <- 0; filled_tot <- 0; expired <- 0; stockout_days <- 0; onhand_sum <- 0; orders <- 0
  for (t in 0:(days - 1)) {
    arr <- pipe_d == t
    if (any(arr)) {
      lot_q <- c(lot_q, pipe_q[arr]); lot_e <- c(lot_e, shelf * stats::runif(sum(arr), 0.8, 0.95))
      pipe_d <- pipe_d[!arr]; pipe_q <- pipe_q[!arr]
    }
    m <- mu * f[t + 1]
    dem <- if (m > 0) m * stats::rlnorm(1, -0.5 * cv_d^2, cv_d) else 0
    demand_tot <- demand_tot + dem
    o <- order(lot_e); lot_q <- lot_q[o]; lot_e <- lot_e[o]
    need <- dem
    for (i in seq_along(lot_q)) {
      take <- min(lot_q[i], need); lot_q[i] <- lot_q[i] - take; need <- need - take
      if (need <= 1e-9) break
    }
    filled_tot <- filled_tot + dem - need
    if (need > 1e-6) stockout_days <- stockout_days + 1
    lot_e <- lot_e - 1
    expired <- expired + sum(lot_q[lot_e <= 0])
    keep <- lot_e > 0 & lot_q > 1e-9; lot_q <- lot_q[keep]; lot_e <- lot_e[keep]
    on_hand <- sum(lot_q); onhand_sum <- onhand_sum + on_hand
    position <- on_hand + sum(pipe_q)
    rop <- mu * mean(f[(t + 1):(t + 1 + floor(lt))]) * lt + ss * f[t + 1]
    if (position <= rop) {
      n <- if (position < rop - Q) ceiling((rop - position) / Q) else 1
      this_lt <- max(1, stats::rnorm(1, lt, lt_sd))
      if (!is.null(outage) && row$primary_plant == outage$plant_id &&
          t >= outage$start_day && t < outage$start_day + outage$duration_days) {
        if (nzchar(row$backup_plant)) this_lt <- this_lt * outage$backup_lead_time_multiplier
        else this_lt <- this_lt + outage$start_day + outage$duration_days - t
      }
      pipe_d <- c(pipe_d, t + round(this_lt)); pipe_q <- c(pipe_q, n * Q); orders <- orders + 1
    }
  }
  data.frame(site_id = row$site_id, sku = row$sku, demand = demand_tot, filled = filled_tot,
             fill_rate = if (demand_tot > 0) filled_tot / demand_tot else 1, stockout_days = stockout_days,
             expired_packs = expired, expired_value_usd = expired * row$unit_cost,
             avg_on_hand = onhand_sum / days, orders = orders, stringsAsFactors = FALSE)
}

#' Simulate every DC x SKU for cfg$sim_days days
pq_simulate <- function(policy, cfg, outage = NULL) {
  set.seed(cfg$sim_seed)
  do.call(rbind, lapply(seq_len(nrow(policy)), function(i) pq_simulate_one(policy[i, ], cfg, outage)))
}

#' Shortage-risk score per SKU (0-100)
pq_shortage_risk <- function(products, sim, target_fill = 0.98) {
  agg <- stats::aggregate(cbind(demand, filled, expired_packs) ~ sku, data = sim, FUN = sum)
  agg$fill_rate <- agg$filled / agg$demand
  df <- merge(products, agg, by = "sku", all.x = TRUE)
  df$fill_rate[is.na(df$fill_rate)] <- 1; df$expired_packs[is.na(df$expired_packs)] <- 0
  df$demand[is.na(df$demand)] <- 0
  clip <- function(x) pmin(pmax(x, 0), 1)
  comp <- data.frame(
    single_source = as.numeric(!nzchar(df$backup_plant)),
    service_gap = clip((target_fill - df$fill_rate) / 0.10),
    demand_volatility = clip((df$demand_cv + df$season_amp / 3) / 0.6),
    lead_time_variability = clip(df$lead_time_sd / df$lead_time_days / 0.35),
    handling_complexity = c(ambient = 0, controlled = 0.7, cold = 1)[df$handling],
    shelf_life_pressure = clip(ifelse(df$demand > 0, df$expired_packs / pmax(df$demand, 1) / 0.02, 0) +
                                 (df$shelf_life_days < 400) * 0.5))
  w <- c(single_source = .25, service_gap = .30, demand_volatility = .15,
         lead_time_variability = .10, handling_complexity = .10, shelf_life_pressure = .10)
  df$risk_score <- 100 * as.numeric(as.matrix(comp[, names(w)]) %*% w)
  df$risk_tier <- as.character(cut(df$risk_score, c(-1, 30, 55, 101), labels = c("Low", "Medium", "High")))
  df$main_driver <- gsub("_", " ", names(comp)[apply(comp, 1, which.max)])
  names(comp) <- paste0("c_", names(comp))
  out <- cbind(df[, c("sku", "name", "handling", "fill_rate", "risk_score", "risk_tier", "main_driver")], comp)
  out <- out[order(-out$risk_score), ]; rownames(out) <- NULL
  out
}

#' Run the full pharmQ pipeline
#' @examples res <- pq_run(pq_config(solver = "heuristic")); res$summary
pq_run <- function(cfg = pq_config(), net = NULL, outage = NULL, forecast_horizon = 26) {
  tm <- list(); t0 <- proc.time()[["elapsed"]]
  lap <- function(name) { t1 <- proc.time()[["elapsed"]]; tm[[name]] <<- round(t1 - t0, 3); t0 <<- t1 }
  if (is.null(net)) net <- pq_build_network(cfg); lap("data")
  national <- tapply(net$demand$annual_packs, net$demand$sku, sum)
  history <- pq_synth_history(net$products, national, seed = cfg$seed)
  fc <- pq_forecast(history, forecast_horizon); lap("forecast")
  sol <- pq_optimize_network(net, cfg); lap("network")
  policy <- pq_inventory_policy(net, sol$lanes, cfg)
  sim <- pq_simulate(policy, cfg, outage)
  risk <- pq_shortage_risk(net$products, sim, cfg$service_level); lap("inventory_sim_risk")
  summary <- c(list(zones = nrow(net$zones), population = sum(net$zones$population),
                    candidate_dcs = nrow(net$sites), skus = nrow(net$products),
                    annual_packs = sum(net$demand$annual_packs)),
               sol$kpis,
               list(solver = sol$solver, inventory_value_usd = sum(policy$inventory_value_usd),
                    fill_rate = sum(sim$filled) / sum(sim$demand),
                    expired_value_usd = sum(sim$expired_value_usd),
                    high_risk_skus = sum(risk$risk_tier == "High"),
                    forecast_wape = mean(fc$accuracy$wape)))
  structure(list(config = cfg, network = net, solution = sol, history = history, forecast = fc$forecast,
                 accuracy = fc$accuracy, policy = policy, sim = sim, risk = risk, summary = summary,
                 timings = tm), class = "pq_results")
}

print.pq_results <- function(x, ...) {
  s <- x$summary
  cat(sprintf(paste0("pharmQ results (%s)\n  DCs open: %d   network cost: $%.1fM/yr   cost/pack: $%.3f\n",
                     "  next-day reach: %.0f%%   fill rate: %.1f%%   inventory: $%.0fM   high-risk SKUs: %d\n"),
              s$solver, s$dcs_open, s$total_cost_usd / 1e6, s$cost_per_pack_usd, 100 * s$pct_pop_next_day,
              100 * s$fill_rate, s$inventory_value_usd / 1e6, s$high_risk_skus))
  invisible(x)
}

#' Write all result tables to CSV plus a JSON summary
pq_export <- function(res, outdir = "results_r") {
  dir.create(outdir, showWarnings = FALSE, recursive = TRUE)
  tabs <- list(zones = res$network$zones, demand = res$network$demand, open_dcs = res$solution$open_sites,
               lanes = res$solution$lanes, forecast = res$forecast, forecast_accuracy = res$accuracy,
               inventory_policy = res$policy, simulation = res$sim, shortage_risk = res$risk)
  for (n in names(tabs)) utils::write.csv(tabs[[n]], file.path(outdir, paste0(n, ".csv")), row.names = FALSE)
  if (requireNamespace("jsonlite", quietly = TRUE))
    jsonlite::write_json(res$summary, file.path(outdir, "summary.json"), auto_unbox = TRUE, pretty = TRUE, digits = NA)
  invisible(normalizePath(outdir))
}
