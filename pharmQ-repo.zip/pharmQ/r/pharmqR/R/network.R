# pharmqR - distribution network design (same model as the Python package)

PQ_BIG <- 1e18
PQ_UNSERVED_PENALTY <- 50

#' Build the cost model: one row per (zone, handling class), one column per candidate DC
pq_cost_model <- function(net, cfg) {
  zones <- net$zones; sites <- net$sites; plants <- net$plants; products <- net$products
  keys <- stats::aggregate(annual_packs ~ zone_id + handling, data = net$demand, FUN = sum)
  names(keys)[names(keys) == "annual_packs"] <- "q"
  keys <- keys[keys$q > 0, ]
  keys <- merge(keys, zones[, c("zone_id", "lat", "lon", "state", "island")], by = "zone_id", sort = FALSE)
  keys <- keys[order(keys$zone_id, keys$handling), ]; rownames(keys) <- NULL

  miles <- pq_distance_matrix(keys$lat, keys$lon, sites$lat, sites$lon)
  same_state <- outer(keys$state, sites$state, "==")
  island_states <- zones$state[zones$island == 1]
  island <- matrix(keys$island == 1, nrow(keys), nrow(sites))
  site_island <- matrix(sites$state %in% island_states, nrow(keys), nrow(sites), byrow = TRUE)
  is_cold <- keys$handling == "cold"
  ground_limit <- ifelse(is_cold, cfg$max_cold_ground_miles, cfg$max_ground_miles)
  air <- ((island | site_island) & !same_state) | (miles > ground_limit)
  mode <- ifelse(air, "air", "ground")
  rate <- pq_rate_for(cfg, keys$handling)
  mult <- ifelse(air, cfg$air_multiplier, 1)

  # inbound cost per pack: volume-weighted distance to each SKU's primary plant
  inbound <- matrix(0, length(HANDLING_CLASSES), nrow(sites), dimnames = list(HANDLING_CLASSES, NULL))
  for (k in HANDLING_CLASSES) {
    dk <- net$demand[net$demand$handling == k, ]
    if (!nrow(dk)) next
    sk <- tapply(dk$annual_packs, dk$sku, sum)
    pp <- products$primary_plant[match(names(sk), products$sku)]
    pi_ <- match(pp, plants$plant_id)
    pm <- pq_distance_matrix(plants$lat[pi_], plants$lon[pi_], sites$lat, sites$lon)
    inbound[k, ] <- colSums(pm * as.numeric(sk / sum(sk))) * cfg$rate_inbound
  }
  cost <- keys$q * (miles * rate * mult + inbound[keys$handling, , drop = FALSE])
  feasible <- matrix(TRUE, nrow(keys), nrow(sites))
  feasible[is_cold, ] <- matrix(as.logical(sites$cold_chain), sum(is_cold), nrow(sites), byrow = TRUE)
  ctrl <- keys$handling == "controlled"
  feasible[ctrl, ] <- matrix(as.logical(sites$dea_vault), sum(ctrl), nrow(sites), byrow = TRUE)
  cost[!feasible] <- PQ_BIG
  list(keys = keys, site_ids = sites$site_id, cost = cost, miles = miles, mode = mode,
       fixed = sites$fixed_cost_musd * 1e6, capacity = sites$capacity_mpacks * 1e6, q = keys$q)
}

#' Capacity-aware greedy assignment by regret
pq_assign <- function(cm, open_mask) {
  idx <- which(open_mask)
  nk <- length(cm$q)
  if (!length(idx)) return(list(assign = rep(NA_integer_, nk), total = sum(cm$q) * PQ_UNSERVED_PENALTY, feasible = FALSE))
  c <- cm$cost[, idx, drop = FALSE]
  if (length(idx) > 1) {
    srt <- t(apply(c, 1, sort))
    regret <- pmin(srt[, 2] - srt[, 1], 1e15)
  } else regret <- c[, 1]
  remaining <- cm$capacity[idx]
  assign <- rep(NA_integer_, nk)
  total <- sum(cm$fixed[idx]); feasible <- TRUE
  for (r in order(-regret)) {
    for (j in order(c[r, ])) {
      if (c[r, j] >= PQ_BIG) break
      if (remaining[j] >= cm$q[r]) {
        assign[r] <- idx[j]; remaining[j] <- remaining[j] - cm$q[r]; total <- total + c[r, j]; break
      }
    }
    if (is.na(assign[r])) { feasible <- FALSE; total <- total + cm$q[r] * PQ_UNSERVED_PENALTY }
  }
  list(assign = assign, total = total, feasible = feasible)
}

#' Greedy add + drop/swap local search
pq_solve_heuristic <- function(cm, cfg) {
  n <- length(cm$site_ids)
  forced <- cm$site_ids %in% cfg$force_open
  closed <- cm$site_ids %in% cfg$force_closed
  open <- forced
  best <- pq_assign(cm, open)$total
  repeat {
    if (sum(open) >= cfg$max_dcs) break
    cand <- NULL
    for (j in which(!open & !closed)) {
      trial <- open; trial[j] <- TRUE
      v <- pq_assign(cm, trial)$total
      if (is.null(cand) || v < cand$v) cand <- list(j = j, v = v)
    }
    if (is.null(cand) || (cand$v >= best && sum(open) >= cfg$min_dcs)) break
    open[cand$j] <- TRUE; best <- cand$v
  }
  improved <- TRUE
  while (improved) {
    improved <- FALSE
    for (j in which(open & !forced)) {
      if (sum(open) > cfg$min_dcs) {
        trial <- open; trial[j] <- FALSE
        v <- pq_assign(cm, trial)$total
        if (v < best - 1e-6) { open <- trial; best <- v; improved <- TRUE; break }
      }
      for (i in which(!open & !closed)) {
        trial <- open; trial[j] <- FALSE; trial[i] <- TRUE
        v <- pq_assign(cm, trial)$total
        if (v < best - 1e-6) { open <- trial; best <- v; improved <- TRUE; break }
      }
      if (improved) break
    }
  }
  open
}

#' MILP with lpSolve: binary open/close decisions, continuous flows (capacity rows link
#' flows to open sites), then each zone x class is single-sourced to its main DC and
#' repaired with the capacity-aware assignment. Fast and near-optimal.
pq_solve_milp <- function(cm, cfg) {
  if (!requireNamespace("lpSolve", quietly = TRUE)) return(NULL)
  nk <- nrow(cm$cost); ns <- ncol(cm$cost)
  pr <- which(cm$cost < PQ_BIG, arr.ind = TRUE)
  rr <- pr[, 1]; jj <- pr[, 2]; np <- length(rr)
  nv <- ns + np
  obj <- c(cm$fixed, cm$cost[pr]) / 1e6
  xi <- ns + seq_len(np)
  # triplets: row, col, value
  t1 <- cbind(rr, xi, 1)                                              # assignment (== 1)
  t2 <- rbind(cbind(nk + jj, xi, cm$q[rr]), cbind(nk + seq_len(ns), seq_len(ns), -cm$capacity))  # capacity (<= 0)
  t3 <- cbind(nk + ns + 1, seq_len(ns), 1)                            # >= min_dcs
  t4 <- cbind(nk + ns + 2, seq_len(ns), 1)                            # <= max_dcs
  fo <- which(cm$site_ids %in% cfg$force_open); fc <- which(cm$site_ids %in% cfg$force_closed)
  extra <- NULL; dir_extra <- NULL; rhs_extra <- NULL; row <- nk + ns + 2
  for (j in fo) { row <- row + 1; extra <- rbind(extra, c(row, j, 1)); dir_extra <- c(dir_extra, "="); rhs_extra <- c(rhs_extra, 1) }
  for (j in fc) { row <- row + 1; extra <- rbind(extra, c(row, j, 1)); dir_extra <- c(dir_extra, "="); rhs_extra <- c(rhs_extra, 0) }
  dense <- rbind(t1, t2, t3, t4, extra)
  dir <- c(rep("=", nk), rep("<=", ns), ">=", "<=", dir_extra)
  rhs <- c(rep(1, nk), rep(0, ns), cfg$min_dcs, cfg$max_dcs, rhs_extra)
  sol <- lpSolve::lp("min", obj, dense.const = dense, const.dir = dir, const.rhs = rhs,
                     int.vec = seq_len(ns))
  if (sol$status != 0) return(NULL)
  open <- sol$solution[seq_len(ns)] > 0.5
  a <- pq_assign(cm, open)
  if (!a$feasible) return(NULL)
  list(open = open, assign = a$assign)
}

#' Optimize the network; returns open sites, lanes and KPIs
pq_optimize_network <- function(net, cfg) {
  cm <- pq_cost_model(net, cfg)
  sol <- NULL; used <- "heuristic"
  if (cfg$solver %in% c("milp", "auto")) { sol <- pq_solve_milp(cm, cfg); used <- "milp" }
  if (is.null(sol)) {
    if (cfg$solver == "milp") stop("MILP solve failed")
    used <- "heuristic"
    open <- pq_solve_heuristic(cm, cfg)
    a <- pq_assign(cm, open); assign <- a$assign; feasible <- a$feasible
  } else { open <- sol$open; assign <- sol$assign; feasible <- !anyNA(assign) }
  if (!feasible) stop("No feasible network: add capacity, cold-chain or DEA-licensed sites, or relax closures.")

  k <- cm$keys; ix <- cbind(seq_len(nrow(k)), assign)
  lanes <- data.frame(zone_id = k$zone_id, state = k$state, handling = k$handling, annual_packs = k$q,
                      zone_lat = k$lat, zone_lon = k$lon, site_id = cm$site_ids[assign],
                      miles = cm$miles[ix], mode = cm$mode[ix], annual_cost_usd = cm$cost[ix],
                      stringsAsFactors = FALSE)
  lanes$transit_days <- pq_transit_days(lanes$miles, lanes$mode)
  lanes$dc_lat <- net$sites$lat[match(lanes$site_id, net$sites$site_id)]
  lanes$dc_lon <- net$sites$lon[match(lanes$site_id, net$sites$site_id)]

  opened <- net$sites[open, ]
  load <- tapply(lanes$annual_packs, lanes$site_id, sum)
  opened$throughput_mpacks <- as.numeric(load[opened$site_id]) / 1e6
  opened$utilization <- opened$throughput_mpacks / opened$capacity_mpacks
  opened$zones_served <- as.integer(tapply(lanes$zone_id, lanes$site_id, function(z) length(unique(z)))[opened$site_id])
  rownames(opened) <- NULL

  amb <- lanes[lanes$handling == "ambient", ]
  pop <- stats::setNames(net$zones$population, net$zones$zone_id)
  fixed <- sum(cm$fixed[open]); transport <- sum(lanes$annual_cost_usd)
  kpis <- list(
    dcs_open = sum(open), fixed_cost_usd = fixed, transport_cost_usd = transport,
    total_cost_usd = fixed + transport, cost_per_pack_usd = (fixed + transport) / sum(lanes$annual_packs),
    avg_miles = stats::weighted.mean(lanes$miles, lanes$annual_packs),
    pct_pop_next_day = sum(pop[amb$zone_id[amb$transit_days <= 2]]) / sum(pop),
    pct_demand_within_500mi = sum(amb$annual_packs[amb$miles <= 500]) / sum(amb$annual_packs),
    pct_volume_air = sum(lanes$annual_packs[lanes$mode == "air"]) / sum(lanes$annual_packs),
    max_utilization = max(opened$utilization))
  list(open_sites = opened, lanes = lanes, kpis = kpis, solver = used)
}
