library(testthat)
library(pharmqR)
test_check("pharmqR")
