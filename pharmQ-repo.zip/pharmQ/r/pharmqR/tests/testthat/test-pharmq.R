test_that("reference data loads and validates", {
  expect_equal(nrow(pq_load("states")), 52)
  expect_true(all(pq_load("products")$handling %in% HANDLING_CLASSES))
  bad <- pq_load("products"); bad$handling[1] <- "frozen"
  expect_error(pq_validate(bad, "products"), "Unknown handling")
})

test_that("haversine is correct (NYC - LA ~ 2445 mi)", {
  expect_equal(pq_haversine(40.71, -74.01, 34.05, -118.24), 2445, tolerance = 0.01)
})

test_that("network respects cold chain, DEA and capacity", {
  cfg <- pq_config(solver = "heuristic")
  net <- pq_build_network(cfg)
  sol <- pq_optimize_network(net, cfg)
  L <- merge(sol$lanes, net$sites, by = "site_id")
  expect_true(all(L$cold_chain[L$handling == "cold"] == 1))
  expect_true(all(L$dea_vault[L$handling == "controlled"] == 1))
  expect_true(all(sol$open_sites$utilization <= 1 + 1e-9))
  expect_equal(sum(sol$lanes$annual_packs), sum(net$demand$annual_packs), tolerance = 1e-6)
})

test_that("forced closures are honoured", {
  cfg <- pq_config(solver = "heuristic", force_closed = c("DC-CMH", "DC-ABE"), include_states = c("OH", "PA", "NY", "NJ"))
  sol <- pq_optimize_network(pq_build_network(cfg), cfg)
  expect_false(any(c("DC-CMH", "DC-ABE") %in% sol$open_sites$site_id))
})

test_that("full pipeline runs and hits service target", {
  res <- pq_run(pq_config(include_states = c("TX", "OK", "LA", "AR", "NM")))
  expect_s3_class(res, "pq_results")
  expect_gt(res$summary$fill_rate, 0.95)
  expect_true(all(res$policy$safety_stock > 0))
  expect_true(all(res$risk$risk_score >= 0 & res$risk$risk_score <= 100))
})

test_that("single-source outage lowers fill rate", {
  cfg <- pq_config(include_states = c("NJ", "NY", "PA"))
  base <- pq_run(cfg)
  hit <- pq_run(cfg, outage = pq_outage("PL-NJ", 10, 120))
  osel <- function(r) r$risk$fill_rate[r$risk$sku == "OSEL75"]
  expect_lt(osel(hit), osel(base))
})
