# pharmQ - Shiny app (R twin of the Streamlit app)
# Run:  shiny::runApp("r/shiny")      (after R CMD INSTALL r/pharmqR, or from the repo root)

library(shiny)
if (requireNamespace("pharmqR", quietly = TRUE)) {
  library(pharmqR)
} else {  # run straight from the repo without installing
  for (f in list.files(file.path("..", "pharmqR", "R"), full.names = TRUE)) source(f)
}
has_maps <- requireNamespace("maps", quietly = TRUE)

states <- pq_load("states"); sites <- pq_load("dc_sites"); plants <- pq_load("plants"); products <- pq_load("products")
HCOL <- c(ambient = "#2E86AB", cold = "#00A6A6", controlled = "#C73E1D")
TCOL <- c(Low = "#3BB273", Medium = "#F4A259", High = "#D7263D")
money <- function(x) {
  if (abs(x) >= 1e9) sprintf("$%.1fB", x / 1e9) else if (abs(x) >= 1e6) sprintf("$%.1fM", x / 1e6)
  else if (abs(x) >= 1e3) sprintf("$%.1fK", x / 1e3) else sprintf("$%.0f", x)
}
kpi <- function(label, value) div(class = "kpi", div(class = "kpi-v", value), div(class = "kpi-l", label))

SCENARIOS <- list(
  "Baseline" = list(),
  "Severe flu season" = list(surge = c("OSEL75", "FLUV"), mult = 2.5),
  "New Jersey plant outage (90 days)" = list(outage = "PL-NJ", days = 90),
  "Columbus + Allentown hubs closed" = list(closed = c("DC-CMH", "DC-ABE")),
  "GLP-1 demand doubles" = list(surge = "SEMA", mult = 2)
)

ui <- fluidPage(
  tags$head(tags$style(HTML("
    body{font-family:system-ui,-apple-system,Segoe UI,sans-serif}
    .kpi{display:inline-block;width:15.5%;min-width:120px;padding:10px 12px;margin:4px;border-radius:10px;background:#f6f7f9}
    .kpi-v{font-size:22px;font-weight:700}.kpi-l{font-size:12px;color:#666}
    .well{background:#fbfbfc}"))),
  titlePanel(div("💊 pharmQ", tags$small(" · US Medicine Distribution Planner (R / Shiny)")), windowTitle = "pharmQ"),
  sidebarLayout(
    sidebarPanel(width = 3,
      selectInput("scenario", "Scenario preset", names(SCENARIOS)),
      checkboxGroupInput("regions", "Regions", sort(unique(states$region)), sort(unique(states$region)), inline = TRUE),
      sliderInput("zps", "Demand zones per large state", 1, 4, 1),
      sliderInput("dmult", "Overall demand level", 0.5, 2, 1, 0.05),
      radioButtons("solver", "Optimizer", c("heuristic", "milp"), inline = TRUE),
      sliderInput("ndc", "DCs allowed", 1, nrow(sites), c(1, 20)),
      selectizeInput("closed", "Force closed", sites$site_id, multiple = TRUE),
      selectizeInput("forced", "Force open", sites$site_id, multiple = TRUE),
      sliderInput("service", "Target service level", 0.90, 0.995, 0.98, 0.005),
      sliderInput("holding", "Holding cost (%/yr)", 0.05, 0.40, 0.22, 0.01),
      numericInput("r_cold", "Cold-chain rate ($/pack-mile)", 0.00035, step = 0.00001),
      checkboxInput("outage_on", "Simulate plant outage", FALSE),
      conditionalPanel("input.outage_on", selectInput("outage_plant", "Plant", plants$plant_id),
                       sliderInput("outage_days", "Outage days", 7, 180, 60)),
      selectizeInput("surge", "Demand surge SKUs", products$sku, multiple = TRUE),
      sliderInput("surge_mult", "Surge multiplier", 1, 4, 1.5, 0.1),
      actionButton("go", "Run model", class = "btn-primary", width = "100%"),
      hr(), helpText("Bring your own data: upload CSVs with the template columns (Export tab)."),
      fileInput("up_sites", "DC sites CSV", accept = ".csv"),
      fileInput("up_products", "Products CSV", accept = ".csv")
    ),
    mainPanel(width = 9,
      uiOutput("kpis"),
      tabsetPanel(
        tabPanel("🗺️ Network map", plotOutput("map", height = 620)),
        tabPanel("🏭 DCs", br(), tableOutput("dcs"), plotOutput("dcbar", height = 320)),
        tabPanel("📈 Forecast", br(), selectInput("fsku", "SKU", products$sku),
                 plotOutput("fplot", height = 380), tableOutput("acc")),
        tabPanel("📦 Inventory", br(), selectInput("pdc", "DC", "All"), tableOutput("policy")),
        tabPanel("🎲 Simulation", plotOutput("heat", height = 480), tableOutput("simtab")),
        tabPanel("⚠️ Risk", plotOutput("risk", height = 420), tableOutput("risktab")),
        tabPanel("📤 Export", br(),
                 downloadButton("dl_zip", "Download all results (.zip)", class = "btn-primary"), br(), br(),
                 downloadButton("dl_sites", "dc_sites.csv template"),
                 downloadButton("dl_products", "products.csv template"),
                 downloadButton("dl_plants", "plants.csv template")),
        tabPanel("ℹ️ About", br(), p("pharmQ plans plants → distribution centers → pharmacies for the whole US:",
                 "demand zones from Census population, Holt-Winters forecasting, facility-location network design with",
                 "cold-chain and DEA constraints, (s,Q) inventory with shelf-life caps, 365-day stochastic simulation",
                 "with lot expiry, and SKU shortage-risk scoring. Bundled cost and demand figures are illustrative."))
      )
    )
  )
)

server <- function(input, output, session) {
  observeEvent(input$scenario, {
    sc <- SCENARIOS[[input$scenario]]
    updateSelectizeInput(session, "closed", selected = if (is.null(sc$closed)) character() else sc$closed)
    updateSelectizeInput(session, "surge", selected = if (is.null(sc$surge)) character() else sc$surge)
    updateSliderInput(session, "surge_mult", value = if (is.null(sc$mult)) 1.5 else sc$mult)
    updateCheckboxInput(session, "outage_on", value = !is.null(sc$outage))
    if (!is.null(sc$outage)) { updateSelectInput(session, "outage_plant", selected = sc$outage)
                               updateSliderInput(session, "outage_days", value = sc$days) }
  })

  res <- eventReactive(input$go, ignoreNULL = FALSE, {
    inc <- states$state[states$region %in% input$regions]
    validate(need(length(inc) > 0, "Select at least one region."))
    surge <- if (length(input$surge)) stats::setNames(as.list(rep(input$surge_mult, length(input$surge))), input$surge) else list()
    cfg <- pq_config(zones_per_state = input$zps, demand_multiplier = input$dmult,
                     include_states = if (length(inc) == nrow(states)) NULL else inc,
                     sku_multipliers = surge, solver = input$solver, min_dcs = input$ndc[1], max_dcs = input$ndc[2],
                     force_closed = input$closed, force_open = setdiff(input$forced, input$closed),
                     service_level = input$service, holding_rate = input$holding, rate_cold = input$r_cold)
    s_up <- if (!is.null(input$up_sites)) utils::read.csv(input$up_sites$datapath, stringsAsFactors = FALSE) else NULL
    p_up <- if (!is.null(input$up_products)) utils::read.csv(input$up_products$datapath, stringsAsFactors = FALSE) else NULL
    out <- if (isTRUE(input$outage_on)) pq_outage(input$outage_plant, 30, input$outage_days) else NULL
    withProgress(message = "Optimizing the national network...", value = 0.3, {
      tryCatch(pq_run(cfg, pq_build_network(cfg, sites = s_up, products = p_up), out),
               error = function(e) { showNotification(conditionMessage(e), type = "error", duration = 10); NULL })
    })
  })

  observe({ r <- res(); req(r); updateSelectInput(session, "pdc", choices = c("All", sort(unique(r$policy$site_id)))) })

  output$kpis <- renderUI({
    r <- res(); req(r); s <- r$summary
    div(kpi("DCs open", s$dcs_open), kpi("Network cost / yr", money(s$total_cost_usd)),
        kpi("Cost per pack", sprintf("$%.3f", s$cost_per_pack_usd)),
        kpi("Next-day reach", sprintf("%.0f%%", 100 * s$pct_pop_next_day)),
        kpi("Simulated fill rate", sprintf("%.1f%%", 100 * s$fill_rate)),
        kpi("Inventory value", money(s$inventory_value_usd)))
  })

  output$map <- renderPlot({
    r <- res(); req(r); L <- r$solution$lanes; o <- r$solution$open_sites; z <- r$network$zones
    par(mar = c(0, 0, 0, 0))
    if (has_maps) maps::map("world", c("USA", "Puerto Rico"), xlim = c(-170, -64), ylim = c(16, 66),
                            fill = TRUE, col = "#f2f2ee", border = "#bbbbbb")
    else plot(z$lon, z$lat, type = "n", axes = FALSE, xlab = "", ylab = "")
    if (has_maps) maps::map("state", add = TRUE, col = "#d0d0d0")
    for (h in names(HCOL)) { S <- L[L$handling == h, ]
      segments(S$dc_lon, S$dc_lat, S$zone_lon, S$zone_lat, col = adjustcolor(HCOL[h], 0.45), lwd = 1) }
    points(z$lon, z$lat, pch = 19, col = adjustcolor("#777777", 0.6), cex = pmin(pmax(sqrt(z$population) / 1500, 0.5), 3))
    cl <- sites[!sites$site_id %in% o$site_id, ]
    points(cl$lon, cl$lat, pch = 0, col = "#999999")
    points(plants$lon, plants$lat, pch = 18, col = "#6A4C93", cex = 1.6)
    points(o$lon, o$lat, pch = 8, col = "#F18F01", cex = 1.5 + o$utilization, lwd = 3)
    text(o$lon, o$lat, sub("DC-", "", o$site_id), pos = 3, cex = 0.8, font = 2)
    legend("bottomleft", c("Open DC", "Closed candidate", "Plant", "Demand zone", names(HCOL)),
           pch = c(8, 0, 18, 19, NA, NA, NA), lty = c(NA, NA, NA, NA, 1, 1, 1),
           col = c("#F18F01", "#999999", "#6A4C93", "#777777", HCOL), bty = "n", cex = 0.9)
  })

  output$dcs <- renderTable({ r <- res(); req(r)
    o <- r$solution$open_sites
    o$utilization <- sprintf("%.0f%%", 100 * o$utilization)
    o[, c("site_id", "city", "state", "throughput_mpacks", "capacity_mpacks", "utilization", "zones_served", "fixed_cost_musd")]
  }, digits = 1)
  output$dcbar <- renderPlot({ r <- res(); req(r)
    m <- xtabs(annual_packs / 1e6 ~ handling + site_id, data = r$solution$lanes)
    barplot(m, col = HCOL[rownames(m)], las = 2, ylab = "M packs / yr", legend.text = TRUE, border = NA,
            args.legend = list(bty = "n"))
  })

  output$fplot <- renderPlot({ r <- res(); req(r)
    h <- r$history[r$history$sku == input$fsku, ]; f <- r$forecast[r$forecast$sku == input$fsku, ]
    plot(h$week, h$packs, type = "l", col = "#555555", xlim = c(0, max(f$week)), ylim = c(0, max(f$hi95, h$packs)),
         xlab = "week", ylab = "national packs / week", main = input$fsku)
    polygon(c(f$week, rev(f$week)), c(f$hi95, rev(f$lo95)), col = adjustcolor("#F18F01", 0.2), border = NA)
    lines(f$week, f$forecast, col = "#F18F01", lwd = 3)
  })
  output$acc <- renderTable({ r <- res(); req(r); r$accuracy }, digits = 3)

  output$policy <- renderTable({ r <- res(); req(r); p <- r$policy
    if (!is.null(input$pdc) && input$pdc != "All") p <- p[p$site_id == input$pdc, ]
    p[, c("site_id", "sku", "handling", "daily_demand", "lead_time", "safety_stock", "reorder_point",
          "reorder_point_peak", "order_qty", "days_of_supply", "inventory_value_usd")]
  }, digits = 0)

  output$heat <- renderPlot({ r <- res(); req(r)
    m <- xtabs(fill_rate ~ sku + site_id, data = r$sim)
    par(mar = c(6, 8, 3, 1))
    image(seq_len(ncol(m)), seq_len(nrow(m)), t(pmax(m, 0.85)), col = hcl.colors(20, "RdYlGn"), zlim = c(0.85, 1),
          axes = FALSE, xlab = "", ylab = "", main = "Fill rate by SKU and DC (365-day simulation)")
    axis(1, seq_len(ncol(m)), colnames(m), las = 2); axis(2, seq_len(nrow(m)), rownames(m), las = 1)
    text(rep(seq_len(ncol(m)), each = nrow(m)), rep(seq_len(nrow(m)), ncol(m)), sprintf("%.2f", m), cex = 0.7)
  })
  output$simtab <- renderTable({ r <- res(); req(r); r$sim }, digits = 3)

  output$risk <- renderPlot({ r <- res(); req(r); k <- r$risk[order(r$risk$risk_score), ]
    par(mar = c(4, 7, 2, 1))
    barplot(k$risk_score, names.arg = k$sku, horiz = TRUE, las = 1, col = TCOL[k$risk_tier], border = NA,
            xlim = c(0, 100), xlab = "Shortage risk score (0-100)")
    legend("bottomright", names(TCOL), fill = TCOL, bty = "n", border = NA)
  })
  output$risktab <- renderTable({ r <- res(); req(r); r$risk[, 1:7] }, digits = 3)

  output$dl_zip <- downloadHandler("pharmq_results_r.zip", function(file) {
    r <- res(); d <- file.path(tempdir(), "pharmq_export"); unlink(d, recursive = TRUE)
    pq_export(r, d); old <- setwd(d); on.exit(setwd(old))
    utils::zip(file, list.files("."), flags = "-q")
  })
  output$dl_sites <- downloadHandler("dc_sites.csv", function(f) utils::write.csv(sites, f, row.names = FALSE))
  output$dl_products <- downloadHandler("products.csv", function(f) utils::write.csv(products, f, row.names = FALSE))
  output$dl_plants <- downloadHandler("plants.csv", function(f) utils::write.csv(plants, f, row.names = FALSE))
}

shinyApp(ui, server)
