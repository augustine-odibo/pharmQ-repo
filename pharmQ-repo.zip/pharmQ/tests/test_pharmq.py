import numpy as np
import pandas as pd
import pytest

from pharmq import Config, Outage, build_network, load_table, run
from pharmq.cli import main as cli_main
from pharmq.forecast import fit_holt_winters, seasonal_factor
from pharmq.geo import haversine_miles
from pharmq.network import optimize_network

SMALL = ["TX", "OK", "LA", "AR", "NM"]


@pytest.fixture(scope="module")
def national():
    return run(Config())


def test_reference_data():
    assert len(load_table("states")) == 52          # 50 states + DC + PR
    assert set(load_table("products")["handling"]) <= {"ambient", "cold", "controlled"}
    bad = load_table("products").assign(handling="frozen")
    from pharmq.data import validate
    with pytest.raises(ValueError, match="Unknown handling"):
        validate(bad, "products")


def test_haversine_nyc_la():
    assert haversine_miles(40.71, -74.01, 34.05, -118.24) == pytest.approx(2445, rel=0.01)


def test_seasonality_mean_is_one():
    w = np.arange(52)
    assert seasonal_factor(w, 1.2, 10).mean() == pytest.approx(1.0, abs=0.01)


def test_holt_winters_recovers_seasonal_signal():
    t = np.arange(156)
    y = 100 + 30 * np.sin(2 * np.pi * t / 52)
    fit = fit_holt_winters(y, 26)
    truth = 100 + 30 * np.sin(2 * np.pi * np.arange(156, 182) / 52)
    assert np.mean(np.abs(fit["forecast"] - truth) / truth) < 0.05


def test_network_constraints(national):
    lanes = national.solution.lanes.merge(national.network.sites, on="site_id")
    assert (lanes.loc[lanes.handling == "cold", "cold_chain"] == 1).all()
    assert (lanes.loc[lanes.handling == "controlled", "dea_vault"] == 1).all()
    assert (national.solution.open_sites["utilization"] <= 1 + 1e-9).all()
    assert lanes["annual_packs"].sum() == pytest.approx(national.network.demand["annual_packs"].sum())
    # every zone x handling served exactly once
    assert not national.solution.lanes.duplicated(["zone_id", "handling"]).any()


def test_milp_not_worse_than_heuristic():
    net = build_network()
    milp = optimize_network(net, Config(solver="milp")).kpis["total_cost_usd"]
    heur = optimize_network(net, Config(solver="heuristic")).kpis["total_cost_usd"]
    assert milp <= heur * 1.0001


def test_force_open_and_closed():
    cfg = Config(force_closed=["DC-DFW"], force_open=["DC-HOU"], include_states=SMALL)
    sol = optimize_network(build_network(include_states=SMALL), cfg)
    assert "DC-DFW" not in set(sol.open_sites.site_id)
    assert "DC-HOU" in set(sol.open_sites.site_id)


def test_infeasible_raises():
    net = build_network(include_states=SMALL)
    with pytest.raises(RuntimeError):
        optimize_network(net, Config(max_dcs=1, force_closed=list(net.sites.site_id)))


def test_pipeline_service_and_risk(national):
    s = national.summary()
    assert s["dcs_open"] >= 3
    assert s["fill_rate"] > 0.95
    assert national.risk["risk_score"].between(0, 100).all()
    assert (national.policy["safety_stock"] > 0).all()


def test_outage_reduces_fill_for_single_source():
    cfg = Config(include_states=["NJ", "NY", "PA"])
    base = run(cfg)
    hit = run(cfg, outage=Outage("PL-NJ", start_day=10, duration_days=120))
    fr = lambda r: r.risk.set_index("sku").loc["OSEL75", "fill_rate"]
    assert fr(hit) < fr(base)


def test_demand_surge_increases_volume():
    a = build_network(include_states=SMALL).demand
    b = build_network(include_states=SMALL, sku_multipliers={"FLUV": 2.0}).demand
    ra = a[a.sku == "FLUV"].annual_packs.sum()
    rb = b[b.sku == "FLUV"].annual_packs.sum()
    assert rb == pytest.approx(2 * ra)


def test_custom_zones():
    zones = pd.DataFrame({"zone_id": ["Z1", "Z2"], "state": ["TX", "TX"], "region": ["South"] * 2,
                          "population": [2_000_000, 1_000_000], "lat": [29.8, 32.8], "lon": [-95.4, -96.8],
                          "island": [0, 0], "pharmacies": [380, 190]})
    res = run(Config(), network=build_network(zones=zones))
    assert set(res.solution.lanes.zone_id) == {"Z1", "Z2"}


def test_cli(tmp_path, capsys):
    rc = cli_main(["run", "--config", "config/default.toml", "--out", str(tmp_path), "--solver", "heuristic"])
    assert rc == 0
    assert (tmp_path / "lanes.csv").exists() and (tmp_path / "summary.json").exists()
